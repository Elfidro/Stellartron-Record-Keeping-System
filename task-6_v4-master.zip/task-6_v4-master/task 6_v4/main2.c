//Note: a zip file is provided with this submission on Bright Space for easy testing
/*code start*/
/*
Name of the program: Relative file for task 6p2
Program summary: This program import txt datas to binary files
ECED 3401
Oct 30, 2021
Author: Henry Zou & Luigi Cortez
Note: a zip file is provided with this submission on Bright Space
*/

#include "relative.h"

/*****************main start***********************/
/*This is the second program that allows import of data in text files*/

//#define mainon

#ifdef mainon



int main(void)
{
    /*all union for all types of ile*/
    CFREC cfile;
    PREC pfile;
    SREC sfile;
    SALEREC salefile;
    PREC productfile;
    CFREC customerfile;
    bool START = true;// this is used in while loop for prompts
    //char ch = 0;
    int input = 0;
    int t = 0;           // type
    FILE* infile = NULL;
    CUSTOMER c_struct;   // temporary customer struct
    PRODUCT p_struct;    // temporary product struct
    SUPPLIER s_struct;   // temporary supplier struct 
    SALE sale_struct;    // temporary sale struct
    int menu_choice = -1;
    int num = 0;
    int return_cost = 0;
    int* rc_ptr = &return_cost;
    char input_string[MAX];

    // User interface and input
    while (START) {
        printf("\nPlease enter the kind of file you want to store: \n");
        printf("Main Menu:\n0 - Exit program\t 1 - Import Data\n\n\n");
        int c = '2';
        menu_choice = get_input(input_string,'2');
        /*menu_choice = 1;*/

        switch (menu_choice) {
        case 0:
            START = false;
            break;
        
        case 1://add files
            printf("\nPlease enter the data type you want to import:\n"
                "0 - Return to main\t1 - Import Customers\t 2 - Import Suppliers\t 3 - Import Products\n");
            /*Restrict user input and get correct input*/
            int c = '3';
            menu_choice = get_input(input_string, '3');

            switch (menu_choice) {
            case 1: // Customers
                num = menu_choice;
                create_bf(&sfd, num);                                             // Create binary file
                read_cfile(sfd, infile, &c_struct, &cfile.hrec);                // Read input file

                fclose(sfd);
                break;
            case 2: // Suppliers
                num = menu_choice;
                create_bf(&sfd, num);                                                        // Create binary file
                read_sfile(sfd, infile, &s_struct, &sfile.hrec);                        // Read input file
                fclose(sfd);
                break;
            case 3: // Products
                num = menu_choice;
                create_bf(&sfd, num);                                                                                  // Create binary file
                read_pfile(sfd, infile, &p_struct, &pfile.hrec);                                                  // Read input file
                fclose(sfd);
                break;
            }
        break;

        case 5: // Make a Sale
            num = 4;//sale is 4
            create_bf(&sfd, num); //define_bf, defined sales file
            //make_a_sale(sfd, &salefile.hrec, &productfile.hrec, &customerfile.hrec);
            fclose(sfd);
            break;
        //case 2:
        //    printf("\nPlease enter the data type you want to add:\n 0 - To the main menu\t 1 - add a customer\t2 - add a supplier\t3 - add a product \n");
        //    /*Restric user input and get correct input*/
        //    char c = '3';
        //    menu_choice = get_input(input_string, &c);

        //    switch (menu_choice) {
        //    case 1:
        //        num = menu_choice;
        //        create_bf(&sfd, num);
        //        add_single_customer(sfd, &cfile.hrec);
        //        break;
        //    case 2:
        //        num = menu_choice;
        //        create_bf(&sfd, num);
        //        add_single_supplier(sfd, &sfile.hrec);
        //        break;
        //    case 3:
        //        num = menu_choice;
        //        create_bf(&sfd, num);
        //        add_single_product(sfd, &pfile.hrec);
        //        break;
        //    }
        //    break;

        }
        //case 3: // Look up
        //    bool LOOKUP = true;

        //    while (LOOKUP) {
        //        printf("\nLook Up Menu:\n0 - Previous Menu\t 1 - Look up customers\t 2 - Look up suppliers\t 3 -Look up products\t 4 - Look up sale \n");

        //        /*Restric user input and get correct input*/
        //        menu_choice = get_input(input_string, '4');
        //        //choice of different files
        //        switch (menu_choice) {
        //        case 0:
        //            LOOKUP = false;
        //            break;
        //        case 1://access customer binary file
        //            t = 1;
        //            create_bf(&sfd, t);
        //            find(t, sfd, 0, 0);
        //            break;
        //        case 2://access supplier binary file
        //            t = 2;
        //            create_bf(&sfd, t);
        //            find(t, sfd, 0, 0);
        //            break;
        //        case 3://access product binary file
        //            t = 3;
        //            create_bf(&sfd, t);
        //            find(t, sfd, 0, 0);
        //            break;
        //        case 4://access sale binary file
        //            t = 4;
        //            create_bf(&sfd, t);
        //            find(t, sfd, 0, 0);
        //            break;
        //        }
        //    }
        //    break;

        

        //}

    }
    return 0;
}
#endif // mainon