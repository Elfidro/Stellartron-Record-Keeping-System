/*
Program summary: contains menu functions
ECED 3401
Oct 17, 2021
Author: Henry Zou & Luigi Cortez
*/

#include "relative.h"

//int m2d[2][12] = {//two dimension array
//{0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334},
//{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31} 
//};
int m2d[12] = {//two dimension array

      31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
};
int get_input(char* input_string,  char options) {
    /*thhis function restricts user input on the menu*/
    int menu_choice = -1;
    fgets(input_string, MAX, stdin);//it reads the screen and output a string atoi()
    if (input_string[0] == '\n') {
        fgets(input_string, MAX, stdin);
    }
    int sz = strlen(input_string); //count how many chars user input_string
    if (sz > 2) {
        printf("Invalid entry.\n");
        menu_choice = -1;
    }
    if (input_string[0] < '0' || input_string[0]>options && sz <= 2) {//only number acceptable

        printf("Invalid entry.\n");
        menu_choice = -1;
    }
    else if (input_string[0] >= '0' && input_string[0] <= options && sz <= 2) {//only 1 to 3 acceptable
        menu_choice = input_string[0] - '0';
    }
    return menu_choice;
}

int input_check(char* input_string) {//only for scanf
    /* this funciton fix two major flaws of scanfand allows scanf to return an
        integer instead of returning a string */
        int menu_choice = 1;
    int i = 0;
    if (input_string[0] == '\n') {//resolve '\n' from scanf passing over
        fgets(input_string, MAX, stdin);

    }
    fgets(input_string, MAX, stdin);
    //int sz = strlen(input_string); //count how many chars user input_string, not used
    if (input_string[0] == '\n' && input_string[1] == '\n') {//email test function to Dr.Hughes
        /* this return -1 to break the infinite loop if invalid entry is entered from scanf */
            menu_choice = -1;
    }

    return menu_choice;

}

int num_only_check(char input_string[MAX], int t) {//case 1 is money check and case 2 is number only check
    /*this function check if the char from the screen is number only*/
    int check = 0;
    char* check_ptr = 0;//need while loops
    int sz = 0;
    int i = 0;
    int j = 0;
    int count = 0;
    char c=0;
    int temp = 0;
    switch (t) {
        case 1:
            sz = strlen(input_string);
            for (j = 0; j < sz; j++) {
                if (input_string[j] == '.') {
                    count++;
                }
            }
            if (count > 1) {
                check = false;
            }
            else {
                for (i = 0; i < sz; i++) {
                    c = input_string[i];
                    if (c >= '0' && c <= '9' || c == '.') {
                        /*VALID_ENTRY = false;*/
                        check = true;
                    }
                    else {
                        
                        check = false;
                    }
                }
            }
            if (check == false) {
                printf("invalid entry\n");
            }
            break;
        case 2:
            sz = strlen(input_string);
            for (i = 0; i < sz; i++) {
                c = input_string[i];
                if (c >= '0' && c <= '9') {
                    /*VALID_ENTRY = false;*/
                    check = true;
                }
                else {
                    printf("invalid entry\n");
                    check = false;
                }
            }

            
            
           
            break;
    }
    
    return check;
    
}

void readscreen(char* input_string) {
    fgets(input_string, MAX, stdin);
    if (input_string[0] == '\n') {
        fgets(input_string, MAX, stdin);
    }
    
}

void delete_menu() {
    /*Restrict user input and get correct input*/
    int menu_choice = 0, num = 0;
    char input_string[MAXLEN];
    menu_choice = get_input(input_string, '3');
    PREC pfile;
    SREC sfile;
    CFREC cfile;
    switch (menu_choice) {
    case 1: // Customers
        num = menu_choice;
        create_bf(&sfd, num);                                   // Create binary file
        delete_a_customer(sfd, &customerfile.hrec);
        fclose(sfd);
        break;
    case 2: // Suppliers
        num = menu_choice;
        create_bf(&sfd, num);                                   // Create binary file
        delete_a_supplier(sfd, &sfile.hrec);
        fclose(sfd);
        break;
    case 3: // Products
        num = menu_choice;
        create_bf(&sfd, num);                                                                                  // Create binary file
        delete_a_product(sfd, &pfile.hrec);
        fclose(sfd);
        break;
    } 
}

void add_menu( ){
    int menu_choice = 0, num = 0;
    char input_string[MAXLEN];
    /*Restric user input and get correct input*/
    menu_choice = get_input(input_string, '3');

    switch (menu_choice) {
    case 1:
        num = menu_choice;
        create_bf(&sfd, num);
        add_single_customer(sfd, &cfile.hrec);
        break;
    case 2:
        num = menu_choice;
        create_bf(&sfd, num);
        add_single_supplier(sfd, &sfile.hrec);
        break;
    case 3:
        num = menu_choice;
        create_bf(&sfd, num);
        add_single_product(sfd, &pfile.hrec);
        break;
    }
    
    
}

void lookup_menu() {
    bool LOOKUP = true;
    int menu_choice = 0, num = 0, t = 0;
    char input_string[MAXLEN];
    while (LOOKUP) {
        /*Restric user input and get correct input*/
        printf("\nLook Up Menu:\n0 - Previous menu\n1 - Look up customers\n2 - Look up suppliers\n3 - Look up products\n4 - Look up sale \n");
        menu_choice = get_input(input_string, '4');
        //choice of different files
        switch (menu_choice) {
        case 0:
            LOOKUP = false;
            break;
        case 1://access customer binary file
            t = 1;
            create_bf(&sfd, t);
            find(t, sfd, 0, 0);
            break;
        case 2://access supplier binary file
            t = 2;
            create_bf(&sfd, t);
            find(t, sfd, 0, 0);
            break;
        case 3://access product binary file
            t = 3;
            create_bf(&sfd, t);
            find(t, sfd, 0, 0);
            break;
        case 4://access sale binary file
            t = 4;
            create_bf(&sfd, t);
            find(t, sfd, 0, 0);
            break;
        }
    }
}

void update_menu() {
    int menu_choice = 0, num = 0, t = 0;
    char input_string[MAXLEN];

    
    menu_choice = get_input(input_string, '3');

    switch (menu_choice) {
    case 1: // Customers
        num = menu_choice;
        create_bf(&sfd, num);                                             // Create binary file
        update_a_customer(sfd, &header);
        fclose(sfd);
        break;
    case 2: // Suppliers
        num = menu_choice;
        create_bf(&sfd, num);                                                        // Create binary file
        update_a_supplier(sfd, &header);
        fclose(sfd);
        break;
    case 3: // Products
        num = menu_choice;
        create_bf(&sfd, num);                                                                                  // Create binary file
        update_a_product(sfd, &header);                                                 // Read input file
        fclose(sfd);
        break;

    }
}

int valid_date(char input_string[MAXLEN]) {//case 1 is money check and case 2 is number only check
    /*this function check if the char from the screen is number only*/
    int check = 0;
    char* check_ptr = 0;//need while loops
    int sz = 0;
    int i = 0, j = 0;
    int count = 0;
    char c = 0;
    int temp = 0;
    char* element;

    sz = strlen(input_string);//21-01-20
    element = strtok(input_string, "-");
    int d = 0, m = 0, y = 0;
    while (element != NUL) // While string pointer is not 0
    {
        int temp;
        temp = atoi(element);
        switch (i) { // Copy the element into the struct
            case 0: y = atoi(element);
                if(y <= 99) {
                    /*VALID_ENTRY = false;*/
                    check = true;
                }
                    else {
                    printf("invalid date\n");
                    check = false;
                    }
                break;
                
            case 1: //check month
                m = atoi(element); 
                if (m <= 12) {
                    /*VALID_ENTRY = false;*/
                    if (check != false) {
                        check = true;
                    }
                    
                }
                else {
                    if (check != false) {
                        printf("invalid date\n");
                    }
                    check = false;
                }
            case 2: d = atoi(element);
                int temp = m2d[m - 1];
                    if (d <= temp) {
                        /*VALID_ENTRY = false;*/
                        if (check != false) {
                            check = true;
                        }
                    }
                    else {
                        if (check != false) {
                            printf("invalid date\n");
                        }
                        
                        check = false;
                    }
                break;
        }
        i++;
        element = strtok(NULL, "-");
    }
    return check;

}

//sz = strlen(input_string);
//for (j = 0; j < sz; j++) {
//    if (input_string[j] == '.') {
//        count++;
//    }
//}
//if (count > 1) {
//    printf("invalid entry\n");
//    check = false;
//}
//else {
//    char c = input_string[i];
//    if (c >= '0' && c <= '9' || c == '.') {
//        /*VALID_ENTRY = false;*/
//        check = true;
//    }
//    else {
//        printf("invalid entry\n");
//        check = false;
//    }
//    i++;
