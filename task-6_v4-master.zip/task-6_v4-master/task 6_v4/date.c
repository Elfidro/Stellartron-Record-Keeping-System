/*
Program summary: contains date functions
ECED 3401
Oct 17, 2021
Author: Henry Zou & Luigi Cortez
*/

#include "relative.h"
//int month2day[2][12] = {//two dimension array
//{0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334},
//{0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335} };
int month2day[2][12] = {//two dimension array
{0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334},
{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31} };



int date_read( int* d, int* m, int* y) {
    /*this function reads the date of year, month, and from screen and return them in integer*/
    /*return 1 if days are read*/
    char input_string[MAX];
    bool INVALID_DATE = true;
    int check = 0;
   
    while (INVALID_DATE) {

        printf("Please enter the date in yy-mm-dd.\n");
        readscreen(input_string);
        check = valid_date(input_string);
        if (check ) {
            INVALID_DATE = false;
        }
    }
   
   
    char* element;

    int sz = 0;
    int valid = true;
    int i = 0;
    sz = strlen(input_string); //count how many chars user input_string
    if (sz > 9) {
        printf("Invalid entry.\n");
        valid = false;
    }
    if (input_string[0] < '0' || input_string[0]>'3' && sz <= 8) {//only 31 days

        printf("Invalid entry.\n");
        valid = false;
    }
    else if (input_string[3] < '0' || input_string[3]>'1' && sz <= 8) {//only 12 months

        printf("Invalid entry.\n");
        valid = false;
    }
    else {
        element = strtok(input_string, "-");
        while (element != NUL) // While string pointer is not 0
        {

            int temp;
            temp = atoi(element);
            switch (i) { // Copy the element into the struct
            case 0: *d = atoi(element); break;
            case 1: *m = atoi(element); break;
            case 2: *y = atoi(element); break;
                break;
            }
            i++;
            element = strtok(NULL, "-");
        }
    }
    //else if (input_string[4] < '0' || input_string[0]>'1' && sz <= 8) {//year check

    //    printf("Invalid entry.\n");
    //    valid = false;
    //}
    return valid;
    return d, m, y;
}

int date2days(int d, int m) {
    /*this function convert a date into days*/
    int days = 0;
    days = d + month2day[1][m];
    return days;
}

void days2date(int days, int* d, int* m, int* y) {
    /*this function convert days into date*/
    int temp = 0;
    for (int i = 0; i < 12; i++) {
        
        temp=days - month2day[1][i];
        if (temp < 0) {
            *m = i - 1;
            *d = days- month2day[1][i - 1]% days;
            *y = 2021;//arbituary value
        }

    }
    return d, m, y;
}