/*
Program summary: This a test main file
*/
#include "relative.h"

//#define TESTINGON//turn on or off this main,

/*****************main start***********************/
#ifdef TESTINGON
int main(void)
{
    int num = 0;
    int return_cost = 0;
    int* rc_ptr = &return_cost;
    char input_string[MAX];
    int menu_choice = 0;
    HEADER header;

    PAYMENT pay_rec;
    CUSTOMER customer_rec;
    //SUPPLIER* supplier_rec = malloc(sizeof(SUPPLIER));
    SUPPLIER supplier_rec;
    PRODUCT product_rec;
    BACKREC backorderfile;
    /*int id = 1;*/
    BACKORDER backorder_struct;


    int current_days = 300;
    /*create_bf(&sfd, 3);
    HEADER header;
    add_single_product(sfd, &header);*/

    /////////
    /*HEADER* ofheader_ptr = malloc(sizeof(OFREC));
    create_bf(&sfd, 8);
    fill_backorder(sfd, ofheader_ptr, 19);
    fclose(sfd);*/

    num = 4;//sale is 4
    create_bf(&sfd, num); //define_bf, defined sales file
    make_a_sale(sfd, &salefile.hrec, &productfile.hrec, &customerfile.hrec, &backorderfile.hrec, &backorder_struct, current_days);
    
    //int t = 3;
    //create_bf(&sfd, t);
    //find(t, sfd, 0, 69);

    /*create_bf(&sfd, 2);*/
    /*fseek(sfd, id * sizeof(SREC), SEEK_SET);
    fread(&supplier_rec, sizeof(SUPPLIER), 1, sfd);*/
    //num = return_supplier(sfd, &supplier_rec, id);
    //create_bf(&sfd, 1);
    //update_a_supplier(sfd, &sfile.hrec);//works
    /*create_bf(&sfd, 3);
    PREC pfile;
    num = return_product(sfd, &product_rec, id);*/
    //update_a_product(sfd, &pfile.hrec);//works

    //return_customer(sfd, &customer_rec, 1001);
    //find(1, sfd, 0, 2);//works




    //create_bf(&sfd, 1); //define_bf, defined sales file
    //return_customer (sfd, &customer_rec, 1000);
    //printf("1111");

    //int d = 0, m = 0, y = 0;
    //days2date(300, &d, &m, &y);
    //printf("New payment due date is: %u-%u-%u\n", y, m, d);



    //main1();

    //num = 4;//sale is 4
    //PAYMENT pay_rec;
    //SALE sale_rec;
    //
    //int id = 1;
    //create_bf(&salefptr, 4); //define_bf, defined sales file
    //fseek(salefptr, (id) * sizeof(SALEREC), SEEK_SET);
    //fread(&sale_rec, sizeof(SALE), 1, salefptr);

    //create_bf(&payfptr, 6);//6 is payment
    ////payment(payfptr, &payfile.hrec, sale_rec, 300);
    //payment(payfptr, sale_rec, 300);
    //
    //create_bf(&payfptr, 6);//6 is payment
    //fseek(payfptr, 1 * sizeof(PAYREC), SEEK_SET);
    //fread(&pay_rec, sizeof(PAYMENT), 1, payfptr);
    //printf("1111");
    /*find_payment(payfptr, 2);
    fclose(payfptr);
    fclose(salefptr);
 */

 //create_bf(&sfd, 1);                                             // Create binary file
 //read_cfile(sfd, infile, &c_struct, &cfile.hrec);

     //readscreen(input_string);
 //printf("%s", input_string);


  //not enough stock

}/************************end of test main**********************/
#endif

//CFREC cfile;
    //PREC pfile;
    //SREC sfile;
    //SALEREC salefile;
    //PREC productfile;
    //CFREC customerfile;
    //BACKREC backorderfile;
    //PAYREC payfile;
    //FILE* payfptr;
    //FILE* salefptr;
    //int t = 0;           // type
    //FILE* infile = NULL;
    //CUSTOMER c_struct;   // temporary customer struct
    //PRODUCT p_struct;    // temporary product struct
    //SUPPLIER s_struct;   // temporary supplier struct 
    //BACKORDER backorder_struct; // temporary backorder struct
    //SALE sale_struct;    // temporary sale struct



    //strcpy(input_string, "d");
    //sz = strlen(
    //for (i = 0; i < sz; i++) {
    //    c = input_string[i];
    //    if (c >= '0' && c <= '9') {
    //        /*VALID_ENTRY = false;*/
    //        //check = true;
    //    }
    //    else {
    //        printf("invalid entry\n");
    //        //check = false;
    //    }
    //}

    /*strtol("600.00", &check_ptr, 10);
    sz = strlen(check_ptr);*/
    //main2();



    //main11();

   /* v*/



    //while loop check
    //bool VALID_ENTRY = true;
    //
    //while (VALID_ENTRY) {
    //    char* check_ptr = 0;//need while loops
    //        int sz = 0;
    //        int i = 0;
    //        int j = 0;
    //        int count = 0;
    //        
    //        printf("enter\n");
    //        fgets(input_string, MAXLEN, stdin);
    //        sz = strlen(input_string);

    //        //strtol(input_string, &input_string, 10);
    //        for (j = 0; j < sz; j++) {
    //            if (input_string[j] == '.') {
    //                count++;
    //            }

    //        }
    //        if (count != 1) {
    //            printf("invalid entry\n");
    //        }
    //        else {
    //            char c = input_string[i];
    //            if (c >= '0' && c <= '9' || c == '.') {

    //                VALID_ENTRY = false;
    //            }
    //            else {
    //                printf("invalid entry\n");
    //            }
    //            i++;
    //        }
    //        
    //        
    //        /*if (sz < 2) {
    //            VALID_ENTRY = false;
    //        }
    //        else {
    //            printf("invalid entry\n");
    //        }*/
    //        //TRUNCATE(newproduct.prec.stock);
    //}


    //main1();

    /*create_bf(&sfd, 3);
    add_single_product(sfd, &pfile.hrec);*/


    //printf("\nPlease enter the today's date in the format of dd/mm/yy\n");
    ////fseek(sfd, (id - 999) * sizeof(CFREC), SEEK_SET);//not equal to zero
    ////fread(&customer_rec, sizeof(CUSTOMER), 1, sfd);//not equal to zero
    //int day = 0, month=0, year=0;
    //int date_converted = 0;
    ////int* dptr = &day, * mptr = &day, * yptr = &day;
    //date_read(input_string, &day, &month, &year);
    //printf("%d %d %d\n", day, month, year);
    //date_converted = date2days(day, month);
    //printf("%d\n", date_converted);




/*printf("\nSale ID \t|\tCustomer ID\t|\tCustomer Name\t\t|\tTotal Number of items purchased\n");
            printf("[ %d ] \t\t\t [ %d ]\t\t[ %s ] \t\t\t [ %d ] \n\n",
                sale_rec.saleid, sale_rec.cid, sale_rec.cname, sale_rec.tnum_purchased);
            printf("\nItems purchased: \n");
            int j = 0, sz = 0;
            sz = sizeof(sale_rec.pid_arr);
            while(sale_rec.pid_arr[j]>0){
                int temp = sale_rec.num_purchased_arr[j];
                printf("Item ID \t|\t\tName of the Product\t|\t# of the Product\t|\tUnitcost\n");
                printf("[ %d ]\t\t", sale_rec.pid_arr[j]);
                printf("[ %s ]\t\t", sale_rec.product_names[j]);
                printf("[ %d ]\t\t\t", sale_rec.num_purchased_arr[j]);
                printf(" $%d.%02d \n\n", sale_rec.product_unit_cost_arr[j] / 100, sale_rec.product_unit_cost_arr[j] % 100);
                j = j + temp;
                j++;
            }*/

            /* Display complete record */
                //printf("\nSale ID \t|\tCustomer ID\t|\tCustomer Name\t\t|\tTotal Number of items purchased\n");//can be combined in look up
                //printf("[ %d ] \t\t\t [ %d ]\t\t[ %s ] \t\t\t [ %d ] \n\n",
                //    newsale.salerec.saleid, newsale.salerec.cid, newsale.salerec.cname, newsale.salerec.tnum_purchased);
                //printf("Items purchased: \n");
                //printf("Item ID \t|\t\tName of the Product\t|\t# of the Product\t|\tUnitcost\n");
                //int k = 0;
                //for (k = 0; k < i; k++) {
                //    int temp = newsale.salerec.num_purchased_arr[k];
                //    
                //    printf("[ %d ]\t\t", newsale.salerec.pid_arr[k]);       
                //    printf("[ %s ]\t\t", newsale.salerec.product_names[k]);
                //    printf("[ %d ]\t\t\t", newsale.salerec.num_purchased_arr[k]);
                //    printf("[ $%d.%02d ]\n\n", newsale.salerec.product_unit_cost_arr[k] / 100, newsale.salerec.product_unit_cost_arr[k] % 100 );
                //    k = k + temp;
                //}