/*
Program summary: contains customer functions
ECED 3401
Oct 17, 2021
Author: Henry Zou & Luigi Cortez
*/

#include "relative.h"

void delete_a_customer(FILE* sfd, HEADER* header_ptr) {//NEED DEBUG
    /*this function delete a customer*/
    char input_string[MAX];
    bool INVALID_ID = true;
    CUSTOMER customer_rec; //1
    /*read header*/
    int id = -1;
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(CFREC), 1, sfd);

    while (INVALID_ID) {
        /*read CID*/
        printf("Please enter the customer ID you want to delete, 0 to exit\n");
        fgets(input_string, MAX, stdin);
        int temp = atoi(input_string) - 999;
        if (temp > header_ptr->first_id - 1 || temp <= 0) {
            printf("Invalid customer id\n");
            if (input_check(input_string) == -1) {
                /*field = -1;;*/
            }
        }
        else if (temp == -999) {
            INVALID_ID = false;
        }
        else {
            INVALID_ID = false;
            id = temp;
            fseek(sfd, id * sizeof(CFREC), SEEK_SET);//not equal to zero
            fread(&customer_rec, sizeof(CUSTOMER), 1, sfd);//not equal to zero
            customer_rec.status = DELETED;
        }
                
        /*write to the file*/
        fseek(sfd, id * sizeof(CFREC), SEEK_SET);
        fwrite(&customer_rec, sizeof(CFREC), 1, sfd);
        printf("The new customer status is:\n");
        find(1, sfd, 0, id);
        fclose(sfd);
    }//the end of while
}

void update_fullname(CUSTOMER* a) {
    /*this funciton update the full name of a customer rec*/
    strcpy(a->cname, a->fname);
    strcat(a->cname, " ");
    strcat(a->cname, a->mname);
    int sz = strlen(a->mname);
    if (sz >= 1) {
        strcat(a->cname, " ");
    }
    strcat(a->cname, a->lname);
    return a;
}

void update_a_customer(FILE* sfd, HEADER* header_ptr) {
    /*this function update a field of a customer rec*/
    char input_string[MAX];
    bool INVALID_ID = true;
    bool UPDATING = true;
    CUSTOMER customer_rec; //1
    int field = -1;
    int id = -1;
    int temp = 0;
    int check = 0;
    /*read header*/
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(CFREC), 1, sfd);
    //field = return_customer(sfd, &customer_rec, id);//1000 base

    while (UPDATING) {
        /*read CID*/
        printf("Please enter the customer ID you want to update\n");
        readscreen(input_string);
        if (input_string[0] == '\n') {
            fgets(input_string, MAX, stdin);
        }
        temp = atoi(input_string) - 999;
        id = atoi(input_string);
        if (temp > header_ptr->first_id - 1 || temp <= 0) {
            printf("Invalid customer id\n");
            field = -1;
        }
        else {
            while (INVALID_ID) {
                    /*read user choice*/
                    if (field != '0') {
                        check = return_customer(sfd, &customer_rec, id);
                        if (check == -1) {
                            field = 0;
                        }
                    }
                    if(field ==-1) {
                        printf("Please enter the field of the customer you want to update\n");
                        printf("0 - Return to main\n1 - Last name\n2 - Middle name\n3 - First name"
                            "\n4 - Buniness\n5 - Street\n6 - Town\n7 - Province\n8 - Postal code\n9 - Phone number\n");
                        bool MENU_CHOICE = true;
                        while (MENU_CHOICE) {
                            fgets(input_string, MAX, stdin);
                            TRUNCATE(input_string);
                            if (num_only_check(input_string, 2) == 1) {
                                field = atoi(input_string);//convert menu input
                                MENU_CHOICE = false;
                            }
                        }
                    }

                    /*update individual field*/
                    switch (field) { // Copy the element into the struct
                        case 0:
                            UPDATING = false;
                            INVALID_ID = false;
                            break;
                        case 1:
                            printf("Enter last name\n");//1
                            fgets(customer_rec.lname, MAXLEN, stdin);
                            TRUNCATE(customer_rec.lname);
                            update_fullname(&customer_rec);
                            break;
                        case 2:
                            printf("Enter middle name\n");//1
                            fgets(customer_rec.mname, MAXLEN, stdin);
                            TRUNCATE(customer_rec.mname);
                            update_fullname(&customer_rec);
                            break;
                        case 3:
                            printf("Enter first name\n");//3
                            fgets(customer_rec.fname, MAXLEN, stdin);
                            TRUNCATE(customer_rec.fname);
                            update_fullname(&customer_rec);
                            break;
                        case 4:
                            printf("Enter business name\n");//4
                            fgets(customer_rec.bname, MAXLEN, stdin);
                            TRUNCATE(customer_rec.bname);
                            break;
                        case 5:
                            printf("Enter street name\n");//5
                            fgets(customer_rec.street, MAXLEN, stdin);
                            TRUNCATE(customer_rec.street);
                            break;
                        case 6:
                            printf("Enter town name\n");//6
                            fgets(customer_rec.town, MAXLEN, stdin);
                            TRUNCATE(customer_rec.town);
                            break;
                        case 7:
                            printf("Enter province name\n");//7
                            fgets(customer_rec.province, MAXLEN, stdin);
                            TRUNCATE(customer_rec.province);
                            break;
                        case 8:
                            printf("Enter postal code\n");//8
                            fgets(customer_rec.postal, MAXLEN, stdin);
                            TRUNCATE(customer_rec.postal);
                            break;
                        case 9:
                            printf("Enter phone number\n");//9
                            fgets(customer_rec.phone, MAXLEN, stdin);
                            TRUNCATE(customer_rec.phone);
                            break;
                    }//the end of switch
                    if (check != -1 && field!=0) {
                        field = -1;//allow to change other fields
                        INVALID_ID = true;//allow to change other fields
                        /*write to the file*/
                        fseek(sfd, (id - 999) * sizeof(CFREC), SEEK_SET);
                        fwrite(&customer_rec, sizeof(CFREC), 1, sfd);
                        printf("The new customer data is:\n");
                        //find(1, sfd, 0, id);//1000 base, cannot print twice
                    }
                    
            }
        }
    }//the end of while
    fclose(sfd);
}
    
void add_customers(FILE* sfd, HEADER* header_ptr, CUSTOMER a)
{
    /* Add a customer to the customer file */
    CFREC newcustomer;
    int id;

    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(CFREC), 1, sfd);

    if (header_ptr->first_id < 0.5) {

        //printf("Start of initialization\n");

        header_ptr->del_rec_list = INVALIDLONG;	/* Deleted list is empty */
        header_ptr->first_id = 1;	    	/* First record is 1*/

        /* Default opening record is 0 (Header) */
        fseek(sfd, 0, SEEK_SET);

        fwrite(header_ptr, sizeof(HEADER), 1, sfd);

        //printf("End of intialization\n");
    }

    /* Access header record to get first available customer id */

    printf("New customer id is: %u\n", header_ptr->first_id + 999);
    id = header_ptr->first_id;

    /* Move to customer record */
    if (fseek(sfd, id * sizeof(CFREC), SEEK_SET) < 0)
    {
        printf("Invalid id\n");
        getchar();
        return;
    }
    /*
     * Record positioned to new record
     * Read data and write to file
    */

    strcpy(newcustomer.crec.lname, a.lname);
    strcpy(newcustomer.crec.mname, a.mname);
    strcpy(newcustomer.crec.fname, a.fname);
    strcpy(newcustomer.crec.cname, a.cname);
    strcpy(newcustomer.crec.bname, a.bname);
    strcpy(newcustomer.crec.street, a.street);
    strcpy(newcustomer.crec.town, a.town);
    strcpy(newcustomer.crec.province, a.province);
    strcpy(newcustomer.crec.postal, a.postal);
    strcpy(newcustomer.crec.phone, a.phone);

    /* Complete remaining fields */
    newcustomer.crec.cid = id;
    newcustomer.crec.status = ACTIVE;
    /* Display complete record */

    printf("[ %d ] [ %s ] [ %s ] [ %s ] [ %s ]",
        newcustomer.crec.cid + 999, newcustomer.crec.fname, newcustomer.crec.mname, newcustomer.crec.lname, newcustomer.crec.bname);
    printf(" [ %s %s %s %s ] [ %s ]\n",
        newcustomer.crec.street, newcustomer.crec.town, newcustomer.crec.province, newcustomer.crec.postal, newcustomer.crec.phone);
    /*
     - Write customer data to customer file
     - File pointer was positioned to customer record
       with fseek() above
    */
    fwrite(&newcustomer, sizeof(CFREC), 1, sfd);

    fseek(sfd, 0, SEEK_SET);
    header_ptr->first_id = header_ptr->first_id + 1;
    fwrite(header_ptr, sizeof(CFREC), 1, sfd);
    return;
}

void read_cfile(FILE* sfd, FILE* infile, CUSTOMER* a, HEADER* header_ptr) {//sfd is a pointer to a file

    // Ask the name of the text file, and open for reading
    char fname[MAX];
    printf("Enter input filename to be read from (include extension such .txt)\n");
    scanf("%s", fname);

    infile = fopen(fname, "r");

    // If file cannot be opened, exit file
    if (infile == NULL) {
        printf("File cannot be opened for reading or does not exist.\n");
        exit(1);
    }

    //infile = fopen("Customers.txt", "r");

    char string[MAX], ch = 0;
    char copy[MAX];
    char* element = 0;
    printf(" CID | Customer name [Firstname] [Middlename] [Lastname] | Business name | Address | Phone \n"); // Prints information header

    while (fgets(string, MAX, infile) > 0) // Reads input file till end of file.
    {
        int i = 0; // Counter variable
        int j = 0; // Counter variable

        /* Takes the string and copies it into customer struct */
        element = strtok(string, ","); // Removes commas from the string
        int sz = 0;
        while (element != NUL) // While string pointer is not 0
        {
            switch (i) { // Copy the element into the struct
            case 0: strcpy(a->cname, element); break;
            case 1: strcpy(a->bname, element); break;
            case 2: strcpy(a->street, element); break;
            case 3: strcpy(a->town, element); break;
            case 4: strcpy(a->province, element); break;
            case 5: strcpy(a->postal, element); break;
            case 6:
                sz = strlen(element);
                element[sz - 2] = NUL;
                strcpy(a->phone, element);
                break;
            }
            i++;
            element = strtok(NULL, ","); // Removes commas from the string
        }

        /* Takes customer name and splits it to firstname, lastname, and middle name. */
        strcpy(copy, a->cname);

        element = strtok(copy, " "); // Removes spaces from the string
        while (element != NUL) {
            switch (j) {
            case 0: strcpy(a->fname, element); break;
            case 1: strcpy(a->lname, element); strcpy(a->mname, "");  break;
            case 2:
                strcpy(a->mname, a->lname);
                strcpy(a->lname, element);
                break;
            }
            j++;
            element = strtok(NULL, " "); // Removes commas from the string

        }

        add_customers(sfd, header_ptr, *a); // Add each customer
    }
    fclose(infile); // Close file
}

void add_single_customer(FILE* sfd, HEADER* header_ptr)
{
    /* Add a customer to the customer file */
    CFREC newcustomer;
    //HEADER hrec;
    //CFREC header;

    int cid;

    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(CFREC), 1, sfd);

    if (header_ptr->first_id < 0.5) {

        //printf("Start of initialization\n");
        //header_ptr->del_rec_list = DEL_END;	/* Deleted list is empty */
        header_ptr->first_id = 1;	    	/* First record is 1*/

        /* Default opening record is 0 (Header) */
        fseek(sfd, 0, SEEK_SET);

        fwrite(header_ptr, sizeof(HEADER), 1, sfd);

        //printf("End of intialization\n");
    }

    printf("New customer id is: %u\n", header_ptr->first_id+999);
    cid = header_ptr->first_id;
    //cid = 1;

    /* Move to customer record */
    if (fseek(sfd, cid * sizeof(CFREC), SEEK_SET) < 0)
    {
        printf("Invalid cid\n");
        getchar();
        return;
    }
    /*
     * Record positioned to new record
     * Read data and write to file
    */
    /* Get last and first name */
    printf("Enter last name\n");
    char ch = 0;
    
    if (ch == '\n') {//removes if scanf scans LF from previous entry
        fgets(newcustomer.crec.lname, MAXLEN, stdin);
        TRUNCATE(newcustomer.crec.lname);
    } 
    
    fgets(newcustomer.crec.lname, MAXLEN, stdin);
    TRUNCATE(newcustomer.crec.lname);

    printf("Enter middle name\n");
    fgets(newcustomer.crec.mname, MAXLEN, stdin);
    TRUNCATE(newcustomer.crec.mname);

    printf("Enter first name\n");
    fgets(newcustomer.crec.fname, MAXLEN, stdin);
    TRUNCATE(newcustomer.crec.fname);

    printf("Enter business name\n");
    fgets(newcustomer.crec.bname, MAXLEN, stdin);
    TRUNCATE(newcustomer.crec.bname);
    //make these into file reading
    printf("Enter street name\n");
    fgets(newcustomer.crec.street, MAXLEN, stdin);
    TRUNCATE(newcustomer.crec.street);
    printf("Enter town name\n");
    fgets(newcustomer.crec.town, MAXLEN, stdin);
    TRUNCATE(newcustomer.crec.town);
    printf("Enter province name\n");
    fgets(newcustomer.crec.province, MAXLEN, stdin);
    TRUNCATE(newcustomer.crec.province);
    printf("Enter postal code\n");
    fgets(newcustomer.crec.postal, MAXLEN, stdin);
    TRUNCATE(newcustomer.crec.postal);
    printf("Enter phone number\n");
    fgets(newcustomer.crec.phone, MAXLEN, stdin);
    TRUNCATE(newcustomer.crec.phone);

    strcpy(newcustomer.crec.cname, newcustomer.crec.fname);
    strcat(newcustomer.crec.cname, " ");
    strcat(newcustomer.crec.cname, newcustomer.crec.mname);
    int sz = strlen(newcustomer.crec.mname);
    if (sz >= 1) {
        strcat(newcustomer.crec.cname, " ");
    }
    strcat(newcustomer.crec.cname, newcustomer.crec.lname);

    /* Complete remaining fields */
    newcustomer.crec.cid = cid;
    newcustomer.crec.status = ACTIVE;
    printf("Complete\n");
    printf("New ID: [ %d ] \n",newcustomer.crec.cid+999);

    fwrite(&newcustomer, sizeof(CFREC), 1, sfd);
   
    fseek(sfd, 0, SEEK_SET);
    header_ptr->first_id = header_ptr->first_id + 1;
    fwrite(header_ptr, sizeof(CFREC), 1, sfd);
    fclose(sfd);
}

//read_cheader();