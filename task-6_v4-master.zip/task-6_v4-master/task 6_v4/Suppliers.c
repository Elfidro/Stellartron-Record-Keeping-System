/*
Program summary: contains supplier functions
ECED 3401
Oct 17, 2021
Author: Henry Zou & Luigi Cortez
*/

#include "relative.h"

void delete_a_supplier(FILE* sfd, HEADER* header_ptr) {
    /**/
    char input_string[MAX];
    bool INVALID_ID = true;
    SUPPLIER supplier_rec; //1
        /*read header*/
    int id = -1;
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(SREC), 1, sfd);

    while (INVALID_ID) {
        /*read CID*/
        printf("Please enter the supplier ID you want to delete, 0 to exit\n");
        fgets(input_string, MAX, stdin);
        int temp = atoi(input_string) - 999;
        if (temp > header_ptr->first_id - 1 || temp <= 0) {
            printf("Invalid supplier id\n");
            if (input_check(input_string) == -1) {
                /*field = -1;;*/
            }
        }
        else if (temp == -999) {
            INVALID_ID = false;
        }
        else {
            INVALID_ID = false;
            id = temp;
            fseek(sfd, id * sizeof(SREC), SEEK_SET);//not equal to zero
            fread(&supplier_rec, sizeof(SUPPLIER), 1, sfd);//not equal to zero
            supplier_rec.s_status = DELETED;
        }

        /*write to the file*/
        fseek(sfd, id * sizeof(SREC), SEEK_SET);
        fwrite(&supplier_rec, sizeof(SREC), 1, sfd);
        printf("The new supplier status is:\n");
        find(1, sfd, 0, id);
        fclose(sfd);
    }//the end of while
}

void update_a_supplier(FILE* sfd, HEADER* header_ptr) {
    /*this function update a field of a supplier rec*/
    char input_string[MAX];
    bool INVALID_ID = true;
    bool UPDATING = true;
    SUPPLIER supplier_rec; //1
    int id = -1;
    int field = -1;
    int check = 0;

    /*read header*/
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(SREC), 1, sfd);
    //field = return_supplier(sfd, &supplier_rec, id);//1000 base
    while (UPDATING) {
        /*read CID*/
        printf("Please enter the supplier ID you want to update\n");
        fgets(input_string, MAX, stdin);
        int temp = atoi(input_string) - 999;
        id = atoi(input_string);
        if (temp > header_ptr->first_id - 1 || temp <= 0) {
            printf("Invalid supplier id\n");
            field = -1;
        }
        else {
            while (INVALID_ID) {

                if (field != '0') {
                    check = return_supplier(sfd, &supplier_rec, id);
                    if (check == -1) {
                        field = 0;
                    }
                }
                if (field == -1) {
                    /*read user choice*/
                    printf("Please enter the field of the supplier you want to update\n");
                    printf("0 - Return to main\n1 - Manufacture\n2 - Contact name\n3 - Company name"
                        "\n4 - Address\n5 - Phone number\n6 - Email\n");
                    bool MENU_CHOICE = true;
                    while (MENU_CHOICE) {
                        fgets(input_string, MAX, stdin);
                        TRUNCATE(input_string);
                        if (num_only_check(input_string, 2) == 1) {
                            field = atoi(input_string);//convert menu input
                            MENU_CHOICE = false;
                        }

                    }
                }
                /*update individual field*/
                switch (field) { // Copy the element into the struct
                case 0:
                    INVALID_ID = false;
                    UPDATING = false;
                    break;
                case 1:
                    printf("Enter manufacturer\n");
                    fgets(supplier_rec.manufacturer, MAXLEN, stdin);
                    TRUNCATE(supplier_rec.manufacturer);
                    //update_fullname(&supplier_rec);
                    break;
                case 2:
                    printf("Enter contact name\n");
                    fgets(supplier_rec.contact, MAXLEN, stdin);
                    TRUNCATE(supplier_rec.contact);            //update_fullname(&supplier_rec);
                    break;
                case 3:
                    printf("Enter company name\n");
                    fgets(supplier_rec.company, MAXLEN, stdin);
                    TRUNCATE(supplier_rec.company);
                    //update_fullname(&supplier_rec);
                    break;
                case 4:
                    printf("Enter address\n");
                    fgets(supplier_rec.address, MAXLEN, stdin);
                    TRUNCATE(supplier_rec.address);
                    break;
                case 5:
                    printf("Enter phone number\n");
                    fgets(supplier_rec.phone, MAXLEN, stdin);
                    TRUNCATE(supplier_rec.phone);
                    break;
                case 6:
                    printf("Enter email\n");
                    fgets(supplier_rec.email, MAXLEN, stdin);
                    TRUNCATE(supplier_rec.email);
                    break;
                }//the end of switch

                if (check != -1 && field != 0) {
                    field = -1;//allow to change other fields
                    INVALID_ID = true;//allow to change other fields
                    /*write to the file*/
                    fseek(sfd, (id - 999) * sizeof(SREC), SEEK_SET);
                    fwrite(&supplier_rec, sizeof(SREC), 1, sfd);
                    printf("The new supplier data is:\n");
                    //find(2, sfd, 0, id);//1-cust1000, 2-supp1000, 3-product
                }
            }//the end of while
        }
    }
    fclose(sfd);
}

void add_suppliers(FILE* sfd, HEADER* header_ptr, SUPPLIER a)
{
    SREC newsupplier;
    //this function add a supplier with different fields
    int id;

    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(SREC), 1, sfd);

    if (header_ptr->first_id < 0.5) {
        //printf("Start of initialization\n");
        header_ptr->del_rec_list = INVALIDLONG;	/* Deleted list is empty */
        header_ptr->first_id = 1;	    	/* First record is 1*/
        /* Default opening record is 0 (Header) */
        fseek(sfd, 0, SEEK_SET);
        fwrite(header_ptr, sizeof(HEADER), 1, sfd);
        //printf("End of intialization\n");
    }

    /* Access header record to get first available id, id starts at 1000 */
    printf("New supplier id is: %u\n", header_ptr->first_id + 999);
    id = header_ptr->first_id;

    /* Move to record */
    if (fseek(sfd, id * sizeof(SREC), SEEK_SET) < 0)
    {
        printf("Invalid id\n");
        getchar();
        return;
    }

    /*copy data to record*/
    strcpy(newsupplier.srec.manufacturer, a.manufacturer);
    strcpy(newsupplier.srec.contact, a.contact);
    strcpy(newsupplier.srec.company, a.company);
    strcpy(newsupplier.srec.address, a.address);
    strcpy(newsupplier.srec.phone, a.phone);
    strcpy(newsupplier.srec.email, a.email);

    /* Complete remaining fields */
    newsupplier.srec.sid = id;
    newsupplier.srec.s_status = ACTIVE;
    /* Display complete record */
    printf("[ %d ] [ %s ] [ %s ] [ %s ] ",
        newsupplier.srec.sid + 999, newsupplier.srec.manufacturer, newsupplier.srec.contact, newsupplier.srec.company);
    printf("[ %s ] [ %s ] [ %s ]\n",
        newsupplier.srec.address, newsupplier.srec.phone, newsupplier.srec.email);

    fwrite(&newsupplier, sizeof(SREC), 1, sfd);//Write data to file

    fseek(sfd, 0, SEEK_SET);//go to header
    header_ptr->first_id = header_ptr->first_id + 1;//increment header available id
    fwrite(header_ptr, sizeof(SREC), 1, sfd);
    return;
}

void read_sfile(FILE* sfd, FILE* infile, SUPPLIER* a, HEADER* header_ptr) {

    // Ask the name of the text file, and open for reading
    char fname[MAX];
    printf("Enter filename to be read from (include extension such .txt)\n");
    scanf("%s", fname);

    infile = fopen(fname, "r");
    // If file cannot be opened, exit file
    if (infile == NULL) {
        printf("File cannot be opened for reading or does not exist.\n");
        exit(1);
    }

    char string[MAX], ch = 0;
    char* element = 0;
    int sz = 0;
    //printf("SID | Manufacturer | Contact | Company | Address | Phone \n"); // Prints information header
    while (fgets(string, MAX, infile) > 0)
    {
        int i = 0; // Counter variable
        element = strtok(string, "\t\""); // Removes tab from string
        /* Takes the string and copies it into supplier struct */
        while (element != NUL)
        {
            switch (i) {
            case 0: strcpy(a->manufacturer, element); break;
            case 1: strcpy(a->contact, element); break;
            case 2: strcpy(a->company, element); break;
            case 3: strcpy(a->address, element); break;
            case 4: strcpy(a->phone, element); break;
            case 5:
                sz = strlen(element);
                element[sz - 1] = NUL;
                element[sz - 2] = NUL;
                strcpy(a->email, element);
                break;
            }
            i++;
            element = strtok(NULL, "\t\""); // Removes tab from element
        }
        add_suppliers(sfd, header_ptr, *a); // Add each supplier
    }
    fclose(infile); // Close file
}

void add_single_supplier(FILE* sfd, HEADER* header_ptr)
{
    /* Add a supplier to the supplier file */
    SREC newsupplier;
    int sid;

    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(SREC), 1, sfd);

    if (header_ptr->first_id < 0.5) {
        //printf("Start of initialization\n");
        header_ptr->first_id = 1;	    	/* First record is 1*/
        /* Default opening record is 0 (Header) */
        fseek(sfd, 0, SEEK_SET);
        fwrite(header_ptr, sizeof(HEADER), 1, sfd);
        //printf("End of intialization\n");
    }

    printf("New supplier id is: %u\n", header_ptr->first_id+999);
    sid = header_ptr->first_id;
    //sid = 1;

    /* Move to supplier record */
    if (fseek(sfd, sid * sizeof(SREC), SEEK_SET) < 0)
    {
        printf("Invalid sid\n");
        getchar();
        return;
    }

    printf("Enter manufacturer\n");
    char ch = 0;
    
    if (ch == '\n') {//removes if scanf scans LF from previous entry
        fgets(newsupplier.srec.manufacturer, MAXLEN, stdin);
        TRUNCATE(newsupplier.srec.manufacturer);
    }
    fgets(newsupplier.srec.manufacturer, MAXLEN, stdin);
    TRUNCATE(newsupplier.srec.manufacturer);
    printf("Enter contact name\n");
    fgets(newsupplier.srec.contact, MAXLEN, stdin);
    TRUNCATE(newsupplier.srec.contact);
    printf("Enter company name\n");
    fgets(newsupplier.srec.company, MAXLEN, stdin);
    TRUNCATE(newsupplier.srec.company);
    printf("Enter address\n");
    fgets(newsupplier.srec.address, MAXLEN, stdin);
    TRUNCATE(newsupplier.srec.address);
    printf("Enter phone number\n");
    fgets(newsupplier.srec.phone, MAXLEN, stdin);
    TRUNCATE(newsupplier.srec.phone);
    printf("Enter email\n");
    fgets(newsupplier.srec.email, MAXLEN, stdin);
    TRUNCATE(newsupplier.srec.email);

    /* Complete remaining fields */
    newsupplier.srec.sid = sid;
    /*newsupplier.srec.status = ACTIVE;*/
    /* Display complete record */
    printf("Complete\n");
    printf("New ID: [ %d ] \n",
        newsupplier.srec.sid+999);
    /*write supplier info*/    
    fwrite(&newsupplier, sizeof(SREC), 1, sfd);
    /*increment header*/
    fseek(sfd, 0, SEEK_SET);
    header_ptr->first_id = header_ptr->first_id + 1;
    fwrite(header_ptr, sizeof(SREC), 1, sfd);
    fclose(sfd);
}

//read_sheader();