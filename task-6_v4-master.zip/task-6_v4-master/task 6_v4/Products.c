/*
Program summary: contains product functions
ECED 3401
Oct 17, 2021
Author: Henry Zou & Luigi Cortez
*/

#include "relative.h"
//TODO: DEBUG CUSTOMER FIRST BEFORE WORKING ON P AND S
void delete_a_product(FILE* sfd, HEADER* header_ptr) {
    /**/
    char input_string[MAX];
    bool INVALID_ID = true;
    PRODUCT product_rec; //1
    /*read header*/
    int id = -1;
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(PREC), 1, sfd);

    while (INVALID_ID) {
        /*read CID*/
        printf("Please enter the product ID you want to delete, 0 to exit\n");
        fgets(input_string, MAX, stdin);
        int temp = atoi(input_string);
        if (temp > header_ptr->first_id - 1 || temp <= 0) {
            printf("Invalid product id\n");
            if (input_check(input_string) == -1) {
                /*field = -1;;*/
            }
        }
        else if (temp == 0) {//RETURN
            INVALID_ID = false;
        }
        else {
            INVALID_ID = false;
            id = temp;
            fseek(sfd, id * sizeof(PREC), SEEK_SET);//not equal to zero
            fread(&product_rec, sizeof(PRODUCT), 1, sfd);//not equal to zero
            product_rec.p_status = DELETED;
        }

        /*write to the file*/
        fseek(sfd, id * sizeof(PREC), SEEK_SET);
        fwrite(&product_rec, sizeof(PREC), 1, sfd);
        printf("The new product status is:\n");
        find(1, sfd, 0, id);
        fclose(sfd);
    }//the end of while
}

void update_a_product(FILE* sfd, HEADER* header_ptr) {
    /*this function update a field of a product rec*/
    char input_string[MAX];
    bool INVALID_ID = true;
    bool UPDATING = true;

    PRODUCT product_rec; //1
    int check = 0;
    int field = -1;
    int id = -1;
    /*read header*/
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(PREC), 1, sfd);
    while (UPDATING) {
        /*read CID*/
        printf("Please enter the product ID you want to update\n");
        fgets(input_string, MAX, stdin);
        int temp = atoi(input_string);
        id = atoi(input_string);
        if (temp > header_ptr->first_id - 1 || temp <= 0) {
            printf("Invalid product id\n");
            field = -1;
        }
        else {
            while (INVALID_ID) {
                if (field != '0') {
                    check = return_product(sfd, &product_rec, id);
                    if (check == -1) {
                        field = 0;
                    }
                }
                if (field == -1) {
                    /*read user choice*/
                    printf("Please enter the field of the product you want to update\n");
                    printf("0 - Return to main\n1 - Product name\n2 - Classification\n3 - Manufacture"
                        "\n4 - Mcode\n5 - Unit cost\n6 - Stock\n");

                    bool MENU_CHOICE = true;
                    while (MENU_CHOICE) {
                        fgets(input_string, MAX, stdin);
                        TRUNCATE(input_string);
                        if (num_only_check(input_string, 2) == 1) {

                            field = atoi(input_string);//convert menu input
                            MENU_CHOICE = false;
                        }
                    }
                }
                /*update individual field*/
                switch (field) { // Copy the element into the struct
                case 0:
                    INVALID_ID = false;
                    UPDATING = false;
                    break;
                case 1:
                    printf("Enter product name\n");
                    fgets(product_rec.name, MAXLEN, stdin);
                    TRUNCATE(product_rec.name);
                    break;
                case 2:
                    printf("Enter classification\n");
                    fgets(product_rec.classification, MAXLEN, stdin);
                    TRUNCATE(product_rec.classification);
                    break;
                case 3:
                    printf("Enter manufacturer\n");
                    fgets(product_rec.manufacturer, MAXLEN, stdin);
                    TRUNCATE(product_rec.manufacturer);
                    break;
                case 4:
                    printf("Enter mcode\n");
                    fgets(product_rec.mcode, MAXLEN, stdin);
                    TRUNCATE(product_rec.mcode);
                    break;
                case 5:
                    bool CHECK_VALID = true;
                    while (CHECK_VALID) {
                        printf("Enter unit cost in the form of EX: 600.00\n");
                        fgets(product_rec.unit_cost, MAXLEN, stdin);
                        TRUNCATE(product_rec.unit_cost);
                        if (num_only_check(product_rec.unit_cost, 1) > 0) {
                            CHECK_VALID = false;
                        }
                    }
                    break;
                case 6:
                    printf("Enter stock\n");//user restriction
                    fgets(product_rec.stock, MAXLEN, stdin);
                    TRUNCATE(product_rec.stock);
                    break;
                }//the end of switch

                if (check != -1 && field != 0) {
                    field = -1;//allow to change other fields
                    INVALID_ID = true;//allow to change other fields
                    /*write to the file*/
                    fseek(sfd, id * sizeof(PREC), SEEK_SET);
                    fwrite(&product_rec, sizeof(PREC), 1, sfd);
                    printf("The new product data is:\n");
                    //find(3, sfd, 0, id);//1-cust, 2-supp, 3-product
                }
            }//the end of while
        }

        
    }//the end of while

    
    fclose(sfd);
}

void add_single_product(FILE* sfd, HEADER* header_ptr)
{
    /* Add a product to the product file */
    PREC newproduct;
    bool VALID_ENTRY = true;
    int pid;

    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(PREC), 1, sfd);

    if (header_ptr->first_id < 0.5) {

        //printf("Start of initialization\n");
        header_ptr->first_id = 1;	    	/* First record is 1*/
        /* Default opening record is 0 (Header) */
        fseek(sfd, 0, SEEK_SET);
        fwrite(header_ptr, sizeof(HEADER), 1, sfd);
        //printf("End of intialization\n");
    }

    printf("New product id is: %u\n", header_ptr->first_id);
    pid = header_ptr->first_id;

    /* Move to product record */
    if (fseek(sfd, pid * sizeof(PREC), SEEK_SET) < 0)
    {
        printf("Invalid pid\n");
        getchar();
        return;
    }

    printf("Enter product name\n");
    char ch = 0;
    if (ch == '\n') {//removes if scanf scans LF from previous entry
        fgets(newproduct.prec.name, MAXLEN, stdin);
        TRUNCATE(newproduct.prec.name);
    }
    fgets(newproduct.prec.name, MAXLEN, stdin);
    TRUNCATE(newproduct.prec.name);
    printf("Enter classification\n");
    fgets(newproduct.prec.classification, MAXLEN, stdin);
    TRUNCATE(newproduct.prec.classification);
    printf("Enter manufacturer\n");
    fgets(newproduct.prec.manufacturer, MAXLEN, stdin);
    TRUNCATE(newproduct.prec.manufacturer);
    printf("Enter mcode\n");
    fgets(newproduct.prec.mcode, MAXLEN, stdin);
    TRUNCATE(newproduct.prec.mcode);
   
    bool   CHECK_VALID = true;
    while (CHECK_VALID) {
        printf("Enter unit cost in the form of EX: 600.00\n");
        fgets(newproduct.prec.unit_cost, MAXLEN, stdin);
        TRUNCATE(newproduct.prec.unit_cost);
        if (num_only_check(newproduct.prec.unit_cost, 1) > 0) {
            CHECK_VALID = false;
            
        }
    }

   /* VALID_ENTRY = true;
    while (VALID_ENTRY) {*/
        printf("Enter stock\n");//user restriction
        fgets(newproduct.prec.stock, MAXLEN, stdin);
        TRUNCATE(newproduct.prec.stock);
    //    if (num_only_check(newproduct.prec.unit_cost, 2) > 0) {
    //        CHECK_VALID = false;
    //    }
    //}

    //convert cost
    char copy[MAX];
    strcpy(copy, newproduct.prec.unit_cost);
    int temp = 0;
    int sz = 0;
    sz = strlen(copy);
    for (int j = 0; j < sz; j++)
    {
        if (copy[j] >= '0' && copy[j] <= '9')
        {
            temp = temp * 10 + (copy[j] - '0');
        }
    }
    newproduct.prec.cost_converted = temp;

    //convert stock
    newproduct.prec.stock_converted=atoi(newproduct.prec.stock);

    /* Complete remaining fields */
    newproduct.prec.pid = pid;
    /*newproduct.PREC.status = ACTIVE;*/
    /* Display complete record */
    printf("Complete\n");
    printf("New ID: [ %d ] \n",
        newproduct.prec.pid);
    fwrite(&newproduct, sizeof(PREC), 1, sfd);
    
    fseek(sfd, 0, SEEK_SET);
    header_ptr->first_id = header_ptr->first_id + 1;
    fwrite(header_ptr, sizeof(PREC), 1, sfd);
    fclose(sfd);
}

void add_products(FILE* sfd, HEADER* header_ptr, PRODUCT a)
{
    //This program adds a product to the binary file
    PREC newproduct;
    int id;

    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(PREC), 1, sfd);

    if (header_ptr->first_id < 0.5) {

        //printf("Start of initialization\n");
        //header_ptr->del_rec_list = INVALIDLONG;	/* Deleted list is empty */
        header_ptr->first_id = 1;	    	/* First record is 1*/
        /* Default opening record is 0 (Header) */
        fseek(sfd, 0, SEEK_SET);
        fwrite(header_ptr, sizeof(HEADER), 1, sfd);
        //printf("End of intialization\n");
    }

    /* Access header record to get first available product id, product id starts 1 */
    printf("New product id is: %u\n", header_ptr->first_id);
    id = header_ptr->first_id;

    /* Move to record */
    if (fseek(sfd, id * sizeof(PREC), SEEK_SET) < 0)
    {
        printf("Invalid id\n");
        getchar();
        return;
    }

    /* Read data and write to file */
    strcpy(newproduct.prec.name, a.name);
    strcpy(newproduct.prec.classification, a.classification);
    strcpy(newproduct.prec.manufacturer, a.manufacturer);
    strcpy(newproduct.prec.unit_cost, a.unit_cost);
    strcpy(newproduct.prec.mcode, a.mcode);
    strcpy(newproduct.prec.stock, a.stock);
    strcpy(newproduct.prec.reorder_level, a.reorder_level);

    /*store converted cost*/
    char copy[MAX];
    strcpy(copy, a.unit_cost);
    int temp = 0;
    int sz = 0;
    sz = strlen(copy);
    for (int j = 0; j < sz; j++)
    {
        if (copy[j] >= '0' && copy[j] <= '9')
        {
            temp = temp * 10 + (copy[j] - '0');
        }
    }
    newproduct.prec.cost_converted = temp;

    /*convert stock*/
    newproduct.prec.stock_converted = atoi(newproduct.prec.stock);

    /*convert reorderlevel*/
    newproduct.prec.reorder_level_converted = atoi(newproduct.prec.reorder_level);

    /* Complete remaining fields */
    newproduct.prec.pid = id;
    newproduct.prec.p_status = ACTIVE;
    /* Display complete record */
    printf(" [ %d ] [ %s ]  [ %s ]  [ %s ]",
        newproduct.prec.pid, newproduct.prec.name, newproduct.prec.classification, newproduct.prec.manufacturer);
    printf(" [ %s ] [ %s ] [ %s ] [ %s ] \n",
        newproduct.prec.unit_cost, newproduct.prec.mcode, newproduct.prec.stock, newproduct.prec.reorder_level);

    fwrite(&newproduct, sizeof(PREC), 1, sfd);//Write product data to product file

    fseek(sfd, 0, SEEK_SET);
    header_ptr->first_id = header_ptr->first_id + 1;//increment header available id
    fwrite(header_ptr, sizeof(PREC), 1, sfd);
    return;
}

void read_pfile(FILE* sfd, FILE* infile, PRODUCT* a, HEADER* header_ptr) {

    //this function reads a text file and call other functions to add data to binary files
    // Ask the name of the text file, and open for reading
    char fname[MAX];
    printf("Enter filename to be read from (include extension such .txt)\n");
    scanf("%s", fname);

    infile = fopen(fname, "r");
    // If file cannot be opened, exit file
    if (infile == NULL) {
        printf("File cannot be opened for reading or does not exist.\n");
        exit(1);
    }

    char string[MAX], ch = 0;
    char copy[MAX];
    char* element = 0;
    int sz = 0;
    printf(" PID | Name | Classification | Manufacturer | Unit cost | Manufacturer code | Stock | Reorder level \n"); // Prints information header

    while (fgets(string, MAX, infile) > 0)
    {
        int i = 0; // Counter variable
        element = strtok(string, "\t\""); // Removes tab from string

        /* Takes the string and copies it into customer struct */
        while (element != NUL)
        {
            switch (i) {
            case 0: strcpy(a->name, element); break;
            case 1: strcpy(a->classification, element); break;
            case 2: strcpy(a->manufacturer, element); break;
            case 3: strcpy(a->unit_cost, element); break;
            case 4: strcpy(a->mcode, element); break;
            case 5:
                sz = strlen(element);
                element[sz - 3] = NUL;
                strcpy(a->stock, element);
                break;
            case 6:
                sz = strlen(element);
                element[sz - 2] = NUL;
                strcpy(a->reorder_level, element);
                break;
            }
            i++;
            element = strtok(NULL, "\t\""); // Removes tab from element
        }
        add_products(sfd, header_ptr, *a);  // Add each product
    }
    fclose(infile); // Close file
}

//read_pheader();