/*
Program summary: contains customer functions
ECED 3401
Dec 1 2021
Author: Henry Zou & Luigi Cortez
*/

#include "relative.h"

void place_backorder(FILE* sfd, HEADER* header_ptr, BACKORDER a,  int current_days) {
	
    //This program adds a product to the binary file
    BACKREC newbackorder;
    int id;
    int i = 0;

    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(BACKREC), 1, sfd);

    if (header_ptr->first_id < 0.5) {

        header_ptr->del_rec_list = INVALIDLONG;	/* Deleted list is empty */
        header_ptr->first_id = 1;	    	/* First record is 1*/

        /* Default opening record is 0 (Header) */
        fseek(sfd, 0, SEEK_SET);

        fwrite(header_ptr, sizeof(HEADER), 1, sfd);
    }

    /* Access header record to get first available backorder id, backorder id starts 1 */

    id = header_ptr->first_id;

    /* Move to record */
    if (fseek(sfd, id * sizeof(BACKREC), SEEK_SET) < 0)
    {
        printf("Invalid id\n");
        getchar();
        return;
    }

    /* Read data and write to file */
    newbackorder.backrec.order_day;
    newbackorder.backrec.cid = a.cid;
    strcpy(newbackorder.backrec.phone, a.phone);
    strcpy(newbackorder.backrec.cname, a.cname);
    newbackorder.backrec.pid = a.pid;
    strcpy(newbackorder.backrec.product_name, a.product_name);
    newbackorder.backrec.num_ordered = a.num_ordered;
    newbackorder.backrec.product_unit_cost = a.product_unit_cost;
    newbackorder.backrec.order_day = current_days;
    int d = 0, m = 0, y = 0;
    printf("Arrival date:\n");
    date_read(&d, &m, &y);
    int arrival_days = date2days(d, m, y);//will give arrival encoded date
    newbackorder.backrec.arrival_day = arrival_days;//ask for arrival date

    /* Complete remaining fields */
    newbackorder.backrec.backorderid = id;

    /* Display complete record */
    printf("Backorder id: \t\t %d \n", newbackorder.backrec.backorderid);
    printf("Customer id: \t\t %d \n", newbackorder.backrec.cid);
    printf("Customer name: \t\t %s \n", newbackorder.backrec.cname);
    printf("Product id: \t\t %d \n", newbackorder.backrec.pid);
    printf("Product name: \t\t %s \n", newbackorder.backrec.product_name);
    printf("Number purchased: \t %d \n", newbackorder.backrec.num_ordered);
    printf("Product unit cost: \t $%d.%02d \n", newbackorder.backrec.product_unit_cost / 100, newbackorder.backrec.product_unit_cost % 100);

    fwrite(&newbackorder, sizeof(BACKREC), 1, sfd);//Write backorder data to customer file

    fseek(sfd, 0, SEEK_SET);
    header_ptr->first_id = header_ptr->first_id + 1;//increment header available id
    fwrite(header_ptr, sizeof(BACKREC), 1, sfd);
    return;
}

void fill_backorder(  int backorderid) {
    OFREC neworderfill;
    FILE* c_ptr;
    FILE* b_ptr;
    FILE* of_ptr;
    int cid = 0;
    int id = 0;
    PRODUCT product_rec;
    CUSTOMER customer_rec;
    BACKORDER backorder_rec;
    HEADER header;
    HEADER* header_ptr = malloc(sizeof(HEADER));
    header_ptr = &header;
    char cname[MAXLEN];
    char phone[20];
    char pname[MAXLEN];
    char prodname[MAXLEN];
    int num_ordered;
    //update the status, change the stock

    // Backorder file opened for reading data
    create_bf(&b_ptr, 5);

    fseek(b_ptr, backorderid * sizeof(BACKREC), SEEK_SET);
    //fseek(b_ptr, 1 * sizeof(BACKORDER), SEEK_SET);
    fread(&backorder_rec, sizeof(BACKORDER), 1, b_ptr);

    cid = backorder_rec.cid - 999;
    num_ordered = backorder_rec.num_ordered;
    strcpy(pname, backorder_rec.product_name);
    strcpy(cname, backorder_rec.cname);
    strcpy(phone, backorder_rec.phone);

    fclose(b_ptr);   
    create_orderfilled(&num_ordered,  pname,  cname, phone);
    
     

    return;
}

void create_orderfilled(int num_ordered, char pname[MAXLEN], char cname[MAXLEN], char phone[MAXLEN]) {
    OFREC neworderfill;
    FILE* b_ptr;
    FILE* of_ptr;
    int id=0;
    BACKORDER backorder_rec;
    HEADER* header_ptr = malloc(sizeof(OFREC));

    // Ordersfilled file creation
    create_bf(&of_ptr, 8);
    fseek(of_ptr, 0, SEEK_SET);
    fread(header_ptr, sizeof(OFREC), 1, of_ptr);

    if (header_ptr->first_id < 0.5) {//initialization

        header_ptr->del_rec_list = INVALIDLONG;	/* Deleted list is empty */
        header_ptr->first_id = 1;	    	    /* First record is 1*/

        /* Default opening record is 0 (Header) */
        fseek(of_ptr, 0, SEEK_SET);
        fwrite(header_ptr, sizeof(HEADER), 1, of_ptr);
    }
    /* Access header record to get first available backorder id, backorder id starts 1 */

    id = header_ptr->first_id;
    neworderfill.ofrec.ordersfilled_id = id;
    /* Complete remaining fields */
    
    strcpy(neworderfill.ofrec.cname, cname);
    strcpy(neworderfill.ofrec.phone, phone);
    strcpy(neworderfill.ofrec.product_name, pname);
    neworderfill.ofrec.num_ordered = num_ordered;
    /* Print debug */
    printf("Orderfill id : \t\t %d \n", neworderfill.ofrec.ordersfilled_id);
    printf("Customer name: \t\t %s \n", neworderfill.ofrec.cname);
    printf("Customer phone: \t %s \n", neworderfill.ofrec.phone);
    printf("Product name: \t\t %s \n", neworderfill.ofrec.product_name);
    printf("Number of items: \t %d \n", neworderfill.ofrec.num_ordered);

    //- Write order data
    fseek(of_ptr, id * sizeof(OFREC), SEEK_SET);
    fwrite(&neworderfill, sizeof(OFREC), 1, of_ptr);//bug

    fseek(of_ptr, 0, SEEK_SET);
    header_ptr->first_id = header_ptr->first_id + 1;
    fwrite(header_ptr, sizeof(OFREC), 1, of_ptr);

    fclose(of_ptr);
  
    
}

bool create_backorder(BACKORDER* a, PRODUCT product_rec, int num, int ids, int current_days){
    char strin[MAXLEN];
    char str1[MAX] = "yes\n";
    char str2[MAX] = "no\n";
    FILE* b_ptr;
    HEADER* bheader_ptr=malloc(sizeof(BACKREC));
    bool CHECK_INPUT = true;
    fgets(strin, MAXLEN, stdin);
    if (strin[0] == '\n') {
        fgets(strin, MAXLEN, stdin);
    }

    if (strcmp(strin, str1) == 0) {
        a->num_ordered = num; 
        a->pid = ids;
        strcpy(a->product_name, product_rec.name);
        a->product_unit_cost = product_rec.cost_converted;
        
        create_bf(&b_ptr, 5);
        fread(bheader_ptr, sizeof(BACKREC), 1, b_ptr);
        place_backorder(b_ptr, bheader_ptr, *a, current_days);
        fclose(b_ptr);
        CHECK_INPUT = false;
    }
    else if (strcmp(strin, str2) == 0) {
        CHECK_INPUT = false;
    }
    else {
        printf("Invalid input.\n\n");
        CHECK_INPUT = true;
    }

    return CHECK_INPUT;
}

void process_backorder(int current_days) {//first called

    /* Read the file sequentially */
    BACKORDER backorder_rec;
    PRODUCT product_rec;
    ORDERSFILLED orderfill_rec;
    //HEADER* ofheader_ptr = malloc(sizeof(OFREC));
    int comp = 0;
    int id [MAXLEN];
    int n = 0;
    int num_ordered [MAXLEN];
    int pid[MAXLEN];
    int i = 0;
    FILE* pfptr;
    FILE* bofptr;
    //FILE* fbofptr;


    //start from beginning
    create_bf(&pfptr, 3);//open product
    create_bf(&bofptr, 5);//open backorder
    /*start from beginning*/
    n = fseek(bofptr, 0, SEEK_SET);
    
    /* when a zero returns terminate read */
    while ((n = fread(&backorder_rec, sizeof(BACKORDER), 1, bofptr)))
    {
        if (backorder_rec.arrival_day > 0) {
            if (current_days == backorder_rec.arrival_day) {
                id[i] = backorder_rec.backorderid;//assign order filled id
                pid[i] = backorder_rec.pid;//assign pid
                i++;
            }
        }
    }
    fclose(bofptr);
    for (int j = 0; j < i;j++) {
        fill_backorder(id[j]);

        orderfill_rec.num_ordered = num_ordered[j];

        return_product(pfptr, &product_rec, pid);
        product_rec.stock_converted = product_rec.stock_converted + num_ordered[j];

    }
    fclose(pfptr);
    return;
}