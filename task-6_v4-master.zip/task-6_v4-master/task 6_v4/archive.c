#include "relative.h"


/*fgets(strin, MAXLEN, stdin);
if (strin[0] == '\n') {
    fgets(strin, MAXLEN, stdin);
}

if (strcmp(strin, str1) == 0) {
    a->num_ordered = num;
    a->pid = ids;
    strcpy(a->product_name, product_rec.name);
    a->product_unit_cost = product_rec.cost_converted;

    create_bf(&b_ptr, 5);
    fread(bheader_ptr, sizeof(BACKREC), 1, b_ptr);
    place_backorder(b_ptr, bheader_ptr, *a, current_days);
    fclose(b_ptr);
    CHECK_INPUT = false;
}
else if (strcmp(strin, str2) == 0) {
    CHECK_INPUT = false;
}
else {
    printf("Invalid input.\n\n");
    CHECK_INPUT = true;
}*/

void find123(int t, FILE* sfd, int* return_cost, int input_id) //can return_cost or print
{
    /*this function finds the input id*/
    CUSTOMER customer_rec; //1
    SUPPLIER supplier_rec; //2
    PRODUCT product_rec;   //3
    SALE sale_rec;         //4
    int id = 0;
    int n;
    char input_str[MAX];
    int returnval = 0;
    id = input_id;
    bool INVALID_ID = true;
    /* when a zero returns terminate read */
    int temp = 0;
    /*start searching different record 1-cust, 2-supp, 3-prod, 4-sale, 5-return cost*/
    switch (t) {
    case 1:
        while (INVALID_ID) {
            if (input_id != 0) {//print only
                id = input_id;
                //fseek(sfd, (id) * sizeof(CFREC), SEEK_SET);//not equal to zero
                //fread(&customer_rec, sizeof(CUSTOMER), 1, sfd);//not equal to zero
                id = id + 999;
                returnval = return_customer(sfd, &customer_rec, id);//1000 base
                if (returnval != -1) {
                    INVALID_ID = false;
                }
            }
            else {//look up and print
                printf("Please enter the Customer ID starting 1000\n");
                scanf("%d", &id);
                if (id < 1000) {
                    printf("Invalid entry, please enter the number again:\n");

                    if (input_check(input_str) == -1) {
                        break;
                    }
                    scanf("%d", &id);
                }

                returnval =return_customer(sfd, &customer_rec, id);//1000 base
                if (customer_rec.cid < 0) {//invalid id re entry
                    printf("Invalid entry, please enter the number again:\n");
                }
                
            }

            if (id >= 1000 && returnval != -1) {
                printf("\nCID:  \t%d  \nFN:  \t%s  \nMN:  \t%s  \nLN:  \t%s  \nBN:  \t%s  \n",
                    customer_rec.cid + 999, customer_rec.fname, customer_rec.mname, customer_rec.lname, customer_rec.bname);
                printf("Addr:  \t%s %s %s %s  \nPhone:  %s\n",
                    customer_rec.street, customer_rec.town,
                    customer_rec.province, customer_rec.postal, customer_rec.phone);
                INVALID_ID = false;
            }
        }

        fclose(sfd);
        break;

    case 2:
        while (INVALID_ID) {

            if (input_id != 0) {//printing only
                id = input_id;
                id = id + 999;
                returnval = return_supplier(sfd, &supplier_rec, id);//1000 base
                if (returnval != -1) {
                    INVALID_ID = false;
                }
            }
            else {//look up and print

                printf("Please enter the Supplier ID starting 1000\n");
                scanf("%d", &id);
                if (id < 1000) {
                    printf("Invalid entry, please enter the number again:\n");
                    if (input_check(input_str) == -1) {
                        break;
                    }
                    scanf("%d", &id);
                }
                returnval = return_supplier(sfd, &supplier_rec, id);//1000 base

                if (supplier_rec.sid < 0) {//invalid id re entry
                    printf("Invalid entry, please enter the number again:\n");

                    //scanf("%d", &id);
                }
                
            }

            if (id >= 1000 && returnval != -1) {
                printf("\nSID:  \t\t%d  \nManufacturer:  \t%s  \nContact:  \t%s  \nCompany:  \t%s\n",
                    supplier_rec.sid + 999, supplier_rec.manufacturer, supplier_rec.contact, supplier_rec.company);
                printf("Addr:  \t\t%s  \nPhone:  \t%s\n",
                    supplier_rec.address, supplier_rec.phone);
                INVALID_ID = false;
            }
        }//end of while

        fclose(sfd);
        break;

    case 3:
        while (INVALID_ID) {
            if (input_id != 0) {//print only
                id = input_id;
                returnval = return_product(sfd, &product_rec, id);//1 base
                if (returnval != -1) {
                    INVALID_ID = false;
                }
            }
            else {//prompt and print
                printf("Please enter the Product ID starting 1\n");
                scanf("%d", &id);

                if (id < 1000) {
                    printf("Invalid entry, please enter the number again:\n");
                    if (input_check(input_str) == -1) {
                        break;
                    }
                    scanf("%d", &id);
                }
                returnval = return_product(sfd, &product_rec, id);//1 base


                if (product_rec.pid < 0) {//invalid id re entry
                    printf("Invalid entry, please enter the number again:\n");
                }
                
            }

            if (id >= 1 && returnval != -1) {
                printf("\nPID: \t\t\t%d \nName: \t\t\t%s \nClassification: \t%s \nManufacturer: \t\t%s \n",
                    product_rec.pid, product_rec.name, product_rec.classification, product_rec.manufacturer);
                printf("Unit Cost: \t\t%s \nManufacturer code: \t%s \nStock: \t\t\t%d \n",
                    product_rec.unit_cost, product_rec.mcode, product_rec.stock_converted);
                INVALID_ID = false;
            }
        }

        fclose(sfd);
        break;
    case 4:
        printf("Please enter the Sale ID starting 1\n");
        scanf("%d", &id);
        fseek(sfd, (id) * sizeof(SALEREC), SEEK_SET);
        fread(&sale_rec, sizeof(SALE), 1, sfd);
        if (sale_rec.saleid < 0) {
            printf("Invalid entry, please enter the number again:\n");
            scanf("%d", &id);
            fseek(sfd, (id) * sizeof(SALEREC), SEEK_SET);
            fread(&sale_rec, sizeof(SALE), 1, sfd);
        }
        if (id > 0) {
            print_sale(sale_rec, sale_rec.tnum_purchased);

            printf("Total cost: $%d.%02d\n", sale_rec.tcost / 100, sale_rec.tcost % 100);
        }

        fclose(sfd);
        break;
    case 5://arbitrary value to represent looking for product cost coverted
        fseek(sfd, (id) * sizeof(PREC), SEEK_SET);
        fread(&product_rec, sizeof(PRODUCT), 1, sfd);

        temp = product_rec.cost_converted;
        *return_cost = temp;

        //fclose(sfd);
        break;

    }
    return;
}

void payment3(FILE* sfd, HEADER* header_ptr, SALE s, int days) {
    int id = 0;
    int d = 0, m = 0, y = 0;
    PAYREC newpay;
    PAYMENT pay_rec, pay_rec2;
    char input_string[MAX];
    //HEADER* header_ptr=malloc(sizeof(PAYREC));//initiallize memory pointer
    //PAYMENT new_payment;
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(PAYREC), 1, sfd);

    if (header_ptr->first_id < 0.5) {

        //printf("Start of initialization\n");
        header_ptr->del_rec_list = INVALIDLONG;	/* Deleted list is empty */
        header_ptr->first_id = 1;	    	/* First record is 1*/
        /* Default opening record is 0 (Header) */
        fseek(sfd, 0, SEEK_SET);
        fwrite(header_ptr, sizeof(HEADER), 1, sfd);
        //printf("End of intialization\n");
    }
    /* Access header record to get first available id */

    printf("New payment id is: %u\n", header_ptr->first_id);
    newpay.payrec.payid = header_ptr->first_id;
    newpay.payrec.pay_status = ACTIVE;
    printf("New payment date is: %u\n", days);
    newpay.payrec.sale_day = days;
    int due_days = days + 30;
    newpay.payrec.due_day = due_days;
    days2date(due_days, &d, &m, &y);
    printf("New payment due date is: %u/%u/%u\n", d, m, y);
    id = newpay.payrec.payid;
    ///* Move to customer record */
    //if (fseek(sfd, id * sizeof(PAYREC), SEEK_SET) < 0)
    //{
    //    printf("Invalid id\n");
    //    getchar();
    //    return;
    //}
    /*transfer input*/
    newpay.payrec.cid = s.cid;
    newpay.payrec.amount_owe = s.tcost;
    strcpy(newpay.payrec.name, s.cname);
    printf("owe: %d\n cid: %d, %d, %s, %d",
        newpay.payrec.amount_owe, newpay.payrec.cid,
        newpay.payrec.due_day, newpay.payrec.name,
        newpay.payrec.payid);
    if (newpay.payrec.pay_status == ACTIVE) {
        printf("1");
    }
    //todo: look up payment info and print
    /*TRUNCATE(newpay.payrec.name);*/
    /*write new payment to the newly available id*/
    fseek(sfd, id * sizeof(PAYREC), SEEK_SET);//???
    fwrite(&newpay, sizeof(PAYREC), 1, sfd);

    fseek(sfd, 0, SEEK_SET);
    header_ptr->first_id = header_ptr->first_id + 1;
    fwrite(header_ptr, sizeof(PAYREC), 1, sfd);

    //printf("1111");
    fclose(sfd);
}