#pragma once
/*
Name of the program: File Uncompressor
Program summary: this is the header file to process relative files
ECED 3401
Oct 17, 2021
Author: Henry Zou & Luigi Cortez
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include <io.h>
#include <stdbool.h>
#include <fcntl.h>     /* for_O_BINARY */

#define NL	'\n'
#define NUL	'\0'
#define MAXLEN	100
#define INVALIDLONG -1l
#define MAX 1000
#define NUM_STRINGS 20
#define MAXMEM 256


FILE* infile;
FILE* sfd;// file pointer declaration

enum REC_STATUS { ACTIVE, DELETED }; // for data records
enum SALE_STATUS { INVOICED, PAID };//for sales

/*******************header*******************/

struct header
{
	long del_rec_list;	/* Deleted record list */
	long first_id;		/* First available id */
	long next_processed_id;//store the payid which has the next process encoded days
};
typedef struct header HEADER;//header

/* Union **gives max record size, fseek() on this */

/*******************customer*******************/
struct deleted_customer
{
	enum REC_STATUS status;
	/* Other information useful for handling deleted records */
	long next_deleted;
};
typedef struct deleted_customer DEL_STU;//deleted customer

struct customer
{
	enum REC_STATUS status;
	char cname[MAXLEN];
	char lname[MAXLEN];
	char mname[MAXLEN];
	char fname[MAXLEN];
	char bname[MAXLEN];
	char street[MAXLEN];
	char town[MAXLEN];
	char province[MAXLEN];
	char postal[MAXLEN];
	char phone[MAXLEN];
	long cid;

	struct customer* first_sale;//linked list for this customer's sales
	//first_sale links to the sale's address
};
typedef struct customer CUSTOMER;

union customer_file
{
	CUSTOMER crec;//customer record
	HEADER hrec;
	DEL_STU drec;
};
typedef union customer_file CFREC;// file record

/*******************supplier*******************/
struct supplier
{
	char manufacturer[MAXLEN];
	char contact[MAXLEN];
	char company[MAXLEN];
	char address[MAXLEN];
	char phone[MAXLEN];
	char email[MAXLEN];
	long sid;//supplier id
	enum REC_STATUS s_status;
};
typedef struct supplier SUPPLIER;

union supplier_file
{
	SUPPLIER srec;//customer record
	HEADER hrec;
	DEL_STU drec;
};
typedef union supplier_file SREC;// file record

/*******************product*******************/
struct product
{
	char name[MAXLEN];
	char classification[MAXLEN];
	char manufacturer[MAXLEN];
	char unit_cost[MAXLEN];
	char mcode[MAXLEN];
	char stock[MAXLEN];
	char reorder_level[MAXLEN];
	int cost_converted;
	int stock_converted;
	int reorder_level_converted;
	int pid;//product id
	enum REC_STATUS p_status;
};
typedef struct product PRODUCT;

union product_file
{
	PRODUCT prec;//customer record
	HEADER hrec;
	DEL_STU drec;
};
typedef union product_file PREC;// file record

/*******************sale*******************/

struct sale
{
	int saleid;
	int tcost;//total cost
	int cid;
	char cname[MAXLEN];
	int tnum_purchased;
	int pid_arr[MAXLEN];// store items' id purchased
	int num_purchased_arr[MAXLEN];
	int product_unit_cost_arr[MAXLEN];
	char product_names[NUM_STRINGS][MAXLEN];
	struct sale* next_sale;//link to the next sale for the same CID
	/*enum SALE_STATUS sale_status;*/
};
typedef struct sale SALE;

union sale_file
{
	SALE salerec;//customer record
	HEADER hrec;
	DEL_STU drec;
};
typedef union sale_file SALEREC;// file record

/*************Payment due*************/

struct payment
{
	int payid;
	int sale_day;//in form of days
	int due_day;//in form of days
	int amount_owe;
	int cid;
	char name[MAXLEN];
	enum PAY_STATUS pay_status;
};
typedef struct payment PAYMENT;

union payment_file
{
	PAYMENT payrec;//customer record
	HEADER hrec;
	//DEL_PAY drec;
};
typedef union payment_file PAYREC;// file record

/***************Backorder due****************/

struct backorder
{
	int order_day;//in form of days
	int arrival_day;//in form of days
	int backorderid;
	int cid;
	char cname[MAXLEN];
	int pid;
	int num_ordered;
	int product_unit_cost;
	char product_name[MAXLEN];
	char phone[MAXLEN];
	
	struct backorder* next_backorder;//link to the next backorder for the same CID
};
typedef struct backorder BACKORDER;

union back_file
{
	BACKORDER backrec;//customer record
	HEADER hrec;
	//DEL_PAY drec;
};
typedef union back_file BACKREC;// file record

/*******************order*******************/

struct order
{
	int order_day;//in form of days
	int arrival_day;//in form of days
	int orderid;
	int pid;
	char product_name[MAXLEN];
	char classification[MAXLEN];
	char mcode[MAXLEN];
	char contact[MAXLEN];
	char phone[MAXLEN];
	char email[MAXLEN];
	int num_ordered;
};
typedef struct order ORDER;

union order_file
{
	ORDER orderrec;//customer record
	HEADER hrec;
	//DEL_PAY drec;
};
typedef union order_file ORDERREC;// file record

/***************ORDERSFILLED****************/

struct ordersfilled
{
	int ordersfilled_id;
	char cname[MAXLEN];
	char phone[MAXLEN];
	char product_name[MAXLEN];
	int num_ordered;
};
typedef struct ordersfilled ORDERSFILLED;

union ordersfilled_file
{
	ORDERSFILLED ofrec;//customer record
	HEADER hrec;
};
typedef union ordersfilled_file OFREC;// file record

#define TRUNCATE(name)	name[strlen(name)-1] = '\0'
/***modules***/
/*customers*/
extern int return_customer(FILE* sfd, CUSTOMER* customer_rec, int id);
extern void add_single_customer(FILE* sfd, HEADER* header_ptr);
extern void read_cfile(FILE* sfd, FILE* infile, CUSTOMER* a, HEADER* header_ptr);
extern void update_a_customer(FILE* sfd, HEADER* header_ptr);
extern void add_customers(FILE*, HEADER*);
extern void delete_a_customer(FILE* sfd, HEADER* header_ptr);
extern void update_fullname(CUSTOMER* a);
/*suppliers*/
extern int return_supplier(FILE* sfd, SUPPLIER* supplier_rec, int id);
extern void add_single_supplier(FILE* sfd, HEADER* header_ptr);
extern void read_sfile(FILE*, FILE*, SUPPLIER*, HEADER*);
extern void add_suppliers(FILE* sfd, HEADER* header_ptr, SUPPLIER a);
extern void update_a_supplier(FILE* sfd, HEADER* header_ptr);
extern void delete_a_supplier(FILE* sfd, HEADER* header_ptr);

/*product*/
extern int return_product(FILE* sfd, PRODUCT* product_rec, int id);
extern void add_single_product(FILE* sfd, HEADER* header_ptr);
extern void read_pfile(FILE* sfd, FILE* infile, PRODUCT* a, HEADER* header_ptr);
extern void add_products(FILE* sfd, HEADER* header_ptr, PRODUCT a);
extern void update_a_product(FILE* sfd, HEADER* header_ptr);
extern void delete_a_product(FILE* sfd, HEADER* header_ptr);
/*binary*/
extern void create_bf(FILE** sfd, int t);
extern void find(int t, FILE* sfd, int* return_cost, int input_id);
extern void return_header(FILE* sfd, HEADER* header_ptr);
extern void find_payment(FILE* sfd, int input_id);
extern void manufacturer_search(FILE* sfd, char* manufacturer, SUPPLIER* a);

/*payment*/
extern void payment(FILE* sfd, SALE s, int days);
extern void sequential_find_pay(FILE* sfd, int current_days);
extern void print_payment(PAYMENT payrec);

/*date*/
extern int date_read(int* d, int* m, int* y);
extern int date2days(int d, int m);
extern void days2date(int days, int* d, int* m, int* y);

/*backorder*/
extern void place_backorder(FILE* sfd, HEADER* header_ptr, BACKORDER a, int current_days);
extern bool create_backorder(BACKORDER* a, PRODUCT product_rec, int num, int ids, int current_days);
extern void fill_backorder(int backorderid);
extern void create_orderfilled(int num_ordered, char pname[MAXLEN], char cname[MAXLEN], char phone[MAXLEN]);
extern void process_backorder(int current_days);

/*menu*/
extern int get_input(char* input_string, char options);
extern int input_check(char* input_string);
extern int num_only_check(char input_string[MAX], int t);
extern void readscreen(char* input_string);
extern void delete_menu();
extern void add_menu();
extern void lookup_menu();
extern void update_menu();
extern int valid_date(char input_string[MAXLEN]);

/*sale*/
extern void make_a_sale(FILE*, HEADER*, HEADER*, HEADER*, HEADER*, BACKORDER*, int current_days);
extern void print_sale(SALE a, int i);

extern void place_order(FILE* sfd, HEADER* header_ptr, HEADER* sheader_ptr, HEADER* pheader_ptr, int pid, int current_days);

//void return_payment(FILE* sfd, PAYMENT* pay_rec, int id);

//extern void return_sale(FILE* sfd, CUSTOMER* a, int id) { ; }
//extern void return_backorder(FILE* sfd, CUSTOMER* a, int id) { ; }
//extern void return_order(FILE* sfd, CUSTOMER* a, int id) { ; }



/*globals for test main*/
//int current_days = 0;
CFREC cfile;
PREC pfile;
SREC sfile;
SALEREC salefile;
PREC productfile;
CFREC customerfile;
BACKREC backorderfile;
BACKORDER backorder_struct; // temporary backorder struct
HEADER header;
CUSTOMER c_struct;   // temporary customer struct
PRODUCT p_struct;    // temporary product struct
SUPPLIER s_struct;   // temporary supplier struct 
SALE sale_struct;    // temporary sale struct