/*
Program summary: contains payment functions
ECED 3401
Oct 17, 2021
Author: Henry Zou & Luigi Cortez
*/

#include "relative.h"

void print_payment(PAYMENT payrec) {
    int due_days=0;
    int d = 0, m = 0, y = 0;
    due_days= payrec.due_day;
    days2date(due_days, &d, &m, &y);
    printf("Payment-due id: %d\nAmount owe: %d\nCid: %d\nCustomer name: %s\nDue date: %d-%d-%d\n\n",
        payrec.payid, payrec.amount_owe, payrec.cid,
        payrec.name, y, m, d);
}

void payment(FILE* sfd,  SALE s, int days) {
    /*this function add a new payment to payment file*/
    int id = 0;
    int d = 0, m = 0, y = 0;
    PAYREC newpay;
    PAYMENT pay_rec, pay_rec2;
    char input_string[MAX];
    HEADER* header_ptr = malloc(sizeof(PAYREC));//initiallize memory pointer
    //PAYMENT new_payment;
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(PAYREC), 1, sfd);

    if (header_ptr->first_id < 0.5) {

        //printf("Start of initialization\n");
        header_ptr->del_rec_list = INVALIDLONG;	/* Deleted list is empty */
        header_ptr->first_id = 1;	    	/* First record is 1*/
        /* Default opening record is 0 (Header) */
        fseek(sfd, 0, SEEK_SET);
        fwrite(header_ptr, sizeof(HEADER), 1, sfd);
        //printf("End of intialization\n");
    }
    /* Access header record to get first available id */

    printf("New payment id is: %u\n", header_ptr->first_id);
    newpay.payrec.payid = header_ptr->first_id;
    newpay.payrec.pay_status = ACTIVE;
    printf("New payment date is: %u\n", days);
    newpay.payrec.sale_day = days;
    int due_days = days + 30;
    newpay.payrec.due_day = due_days;
    days2date(due_days, &d, &m, &y);
    printf("New payment due date is: %u/%u/%u\n", d, m, y);
    id = newpay.payrec.payid;
   
    newpay.payrec.cid = s.cid;
    newpay.payrec.amount_owe = s.tcost;
    strcpy(newpay.payrec.name, s.cname);
    print_payment(newpay.payrec);
    
    //todo: look up payment info and print
    /*TRUNCATE(newpay.payrec.name);*/
    /*write new payment to the newly available id*/
    fseek(sfd, id * sizeof(PAYREC), SEEK_SET);//???
    fwrite(&newpay, sizeof(PAYREC), 1, sfd);

    fseek(sfd, 0, SEEK_SET);
    header_ptr->first_id = header_ptr->first_id + 1;
    fwrite(header_ptr, sizeof(PAYREC), 1, sfd);

    //printf("1111");
    fclose(sfd);
}

//void next_payment_due(FILE* sfd, int current_days) {
//
//    sequential_find_pay(sfd, current_days);
//
//}

void sequential_find_pay(FILE* sfd, int current_days) {
    int n;
    PAYMENT payment_rec;
    HEADER* header_ptr = malloc(sizeof(PAYREC));

    /*debug below*/
    return_pay_header(sfd, header_ptr);//return header
    int due_id = header_ptr->next_processed_id;
    //start from beginning
    n = fseek(sfd, due_id * sizeof(PAYREC), SEEK_SET);
    /*end*/

    /* when a zero returns terminate read */
    printf("These payments are due today:\n");
    while ((n = fread(&payment_rec, sizeof(PAYMENT), 1, sfd)))
    {
        if (payment_rec.payid > 0) {

            if (current_days == payment_rec.due_day) {
                print_payment(payment_rec);
                break;
            }
        }
    }
}

int return_payment(FILE* sfd, PAYMENT* payment_rec, int id) {
    int delete = 0;
    fseek(sfd, (id) * sizeof(PAYREC), SEEK_SET);
    fread(payment_rec, sizeof(PAYMENT), 1, sfd);
    if (payment_rec->pay_status == PAID) {
        printf("Record was paid\n");
        delete = -1;
    }
    return delete;
}

