/*
Program summary: contains customer functions
ECED 3401
Dec 1 2021
Author: Henry Zou & Luigi Cortez
*/

#include "relative.h"

void place_order(FILE* sfd, HEADER* header_ptr, HEADER* sheader_ptr, HEADER* pheader_ptr, int pid, int current_days, int order_amount) {
    ORDERREC neworder;
    FILE* p_ptr;
    FILE* s_ptr;
    int id;
    int num_reorder = 0; //number of items to be ordered
    bool CHECK_VALID_DATE = true;
    PRODUCT product_rec;
    SUPPLIER supplier_rec;
    char pname[MAXLEN];
    char classification[MAXLEN];
    char mcode[MAXLEN];
    char manufacturer[50];
    
    // Product file opened for reading data

    create_bf(&p_ptr, 3);

    fseek(p_ptr, pid * sizeof(PREC), SEEK_SET);
    fread(&product_rec, sizeof(PRODUCT), 1, p_ptr);

    strcpy(pname, product_rec.name);
    strcpy(classification, product_rec.classification);
    strcpy(mcode, product_rec.mcode);
    strcpy(manufacturer, product_rec.manufacturer);

    fclose(p_ptr);

    // Supplier file opened for reading data
    
    create_bf(&s_ptr, 2);
    manufacturer_search(s_ptr, manufacturer, &supplier_rec);
    fclose(s_ptr);


    // orderfile creation
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(ORDERREC), 1, sfd);

    if (header_ptr->first_id < 0.5) {//ini

        header_ptr->del_rec_list = INVALIDLONG;	/* Deleted list is empty */
        header_ptr->first_id = 1;	    	    /* First record is 1*/

        /* Default opening record is 0 (Header) */
        fseek(sfd, 0, SEEK_SET);

        fwrite(header_ptr, sizeof(HEADER), 1, sfd);

    }

    /* Access header record to get first available backorder id, backorder id starts 1 */

    id = header_ptr->first_id;

    /* Complete remaining fields */
    neworder.orderrec.orderid = id;
    neworder.orderrec.order_day = current_days;
    neworder.orderrec.pid = pid;
    strcpy(neworder.orderrec.product_name, pname);
    strcpy(neworder.orderrec.classification, classification);
    strcpy(neworder.orderrec.mcode, mcode);
    strcpy(neworder.orderrec.contact, supplier_rec.contact);
    strcpy(neworder.orderrec.phone, supplier_rec.phone);
    strcpy(neworder.orderrec.email, supplier_rec.email);
    neworder.orderrec.num_ordered = order_amount;

    
    int d = 0, m = 0, y = 0;
    date_read(&d, &m, &y);

    int arrival_days = date2days(d, m, y);//will give arrival encoded date
    neworder.orderrec.arrival_day = arrival_days;//ask for arrival date

    /* Print debug */
    printf("Order id : \t\t\t %d \n", neworder.orderrec.orderid);
    printf("Product id: \t\t\t %d \n", neworder.orderrec.pid);
    printf("Product name: \t\t\t %s \n", neworder.orderrec.product_name);
    printf("Product manufacturer code: \t %s \n", neworder.orderrec.mcode);
    printf("Supplier contact: \t\t %s \n", neworder.orderrec.contact);
    printf("Supplier phone: \t\t %s \n", neworder.orderrec.phone);
    printf("Supplier email: \t\t %s \n", neworder.orderrec.email);
    printf("Amount ordered: \t\t %d \n", neworder.orderrec.num_ordered);


    //- Write order data
    fseek(sfd, id * sizeof(ORDERREC), SEEK_SET);
    fwrite(&neworder, sizeof(ORDERREC), 1, sfd);//bug

    fseek(sfd, 0, SEEK_SET);
    header_ptr->first_id = header_ptr->first_id + 1;
    fwrite(header_ptr, sizeof(ORDERREC), 1, sfd);

    fclose(sfd);
    return;
}

