/*
Program summary: contains binary functions
ECED 3401
Oct 17, 2021
Author: Henry Zou & Luigi Cortez
*/

#include "relative.h"

void return_pay_header(FILE* sfd, HEADER *header_ptr) {
    //create_bf?
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(PAYREC), 1, sfd);
    
}
void return_back_header(FILE* sfd, HEADER* header_ptr) {
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(BACKREC), 1, sfd);
}
void return_order_header(FILE* sfd, HEADER* header_ptr) {
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(ORDERREC), 1, sfd);
}

int return_customer(FILE* sfd, CUSTOMER* customer_rec, int id) {//returns customer_rec infor and check deletiong
    int delete = 0;
    fseek(sfd, (id - 999) * sizeof(CFREC), SEEK_SET);//not equal to zero
    fread(customer_rec, sizeof(CUSTOMER), 1, sfd);//not equal to zero
    if (customer_rec->status == DELETED) {
        printf("Record was deleted\n");
        delete = -1;
    }
    return delete;
}
int return_supplier(FILE* sfd, SUPPLIER* supplier_rec, int id) {
    int delete = 0;

    fseek(sfd, (id - 999) * sizeof(SREC), SEEK_SET);
    fread(supplier_rec, sizeof(SUPPLIER), 1, sfd);
    if (supplier_rec->s_status == DELETED) {
        printf("Record was deleted\n");
        delete = -1;
    }
    return delete;
}
int return_product(FILE* sfd, PRODUCT* product_rec, int id) {
    int delete = 0;
    fseek(sfd, (id) * sizeof(PREC), SEEK_SET);
    fread(product_rec, sizeof(PRODUCT), 1, sfd);
    if (product_rec->p_status == DELETED) {
        printf("Record was deleted\n");
        delete = -1;
    }
    return delete;
}

void create_bf(FILE** sfd, int t) {
    //This function created a binary file that is ready for writing
    char cust[MAX] = "Customers";//binary file names
    char supp[MAX] = "Suppliers";
    char prod[MAX] = "Products";
    char sale[MAX] = "Sales";
    char backorder[MAX] = "backorders.dat";
    char order[MAX] = "ORDERS";// need to concatenate date
    char payment[MAX] = "PAY-DUE";
    char ordersfilled[MAX] = "ORDERSFILLED";// need to concatenate date
    ///* Set file access mode */
    switch (t) {
    case 1:
        _set_fmode(_O_BINARY);
        if (fopen_s(sfd, cust, _access(cust, 0) < 0 ? "w" : "r+") != 0) // If file can be opened, open file for writing
        {
            printf("Can't open %s\n", cust);
            exit(1);
        }
        break;
    case 2:
        _set_fmode(_O_BINARY);
        if (fopen_s(sfd, supp, _access(supp, 0) < 0 ? "w" : "r+") != 0) // If file can be opened, open file for writing
        {
            printf("Can't open %s\n", supp);
            exit(1);
        }
        break;
    case 3:
        _set_fmode(_O_BINARY);
        if (fopen_s(sfd, prod, _access(prod, 0) < 0 ? "w" : "r+") != 0) // If file can be opened, open file for writing
        {
            printf("Can't open %s\n", prod);
            exit(1);
        }
        break;
    case 4:
        _set_fmode(_O_BINARY);
        if (fopen_s(sfd, sale, _access(sale, 0) < 0 ? "w" : "r+") != 0) // If file can be opened, open file for writing
        {
            printf("Can't open %s\n", sale);
            exit(1);
        }
        break;
    case 5:
        _set_fmode(_O_BINARY);
        if (fopen_s(sfd, backorder, _access(backorder, 0) < 0 ? "w" : "r+") != 0) // If file can be opened, open file for writing
        {
            printf("Can't open %s\n", backorder);
            exit(1);
        }
        break;
    case 6:
        _set_fmode(_O_BINARY);
        if (fopen_s(sfd, payment, _access(payment, 0) < 0 ? "w" : "r+") != 0) // If file can be opened, open file for writing
        {
            printf("Can't open %s\n", payment);
            exit(1);
        }
        break;
    case 7:
        _set_fmode(_O_BINARY);
        if (fopen_s(sfd, order, _access(order, 0) < 0 ? "w" : "r+") != 0) // If file can be opened, open file for writing
        {
            printf("Can't open %s\n", order);
            exit(1);
        }
        break;
    case 8:
        _set_fmode(_O_BINARY);
        if (fopen_s(sfd, ordersfilled, _access(ordersfilled, 0) < 0 ? "w" : "r+") != 0) // If file can be opened, open file for writing
        {
            printf("Can't open %s\n", ordersfilled);
            exit(1);
        }
        break;

    }

}

void find(int t, FILE* sfd, int* return_cost, int input_id) //can return_cost or print
{
    /*this function finds the input id*/
    CUSTOMER customer_rec; //1
    SUPPLIER supplier_rec; //2
    PRODUCT product_rec;   //3
    SALE sale_rec;         //4
    int id = 0;
    int n;
    int returnval = 0;
    char input_str[MAX];
    id = input_id;
    bool INVALID_ID = true;
    /* when a zero returns terminate read */
    int temp = 0;
    /*start searching different record 1-cust, 2-supp, 3-prod, 4-sale, 5-return cost*/
    switch (t) {
    case 1:
        while (INVALID_ID) {
            if (input_id != 0) {//print only
                id = input_id;
                returnval = return_customer(sfd, &customer_rec, id);//1000 base
                if (returnval != -1) {
                    INVALID_ID = false;
                }
            }
            else {//look up and print
                printf("Please enter the Customer ID starting 1000\n");
                scanf("%d", &id);
                if (id < 1000) {
                    printf("Invalid entry, please enter the number again:\n");

                    if (input_check(input_str) == -1) {
                        break;
                    }
                    scanf("%d", &id);
                }

                returnval = return_customer(sfd, &customer_rec, id);//1000 base
                if (customer_rec.cid < 0) {//invalid id re entry
                    printf("Invalid entry, please enter the number again:\n");
                }

            }

            if (id >= 1000 && returnval != -1) {
                printf("\nCID:  \t%d  \nFN:  \t%s  \nMN:  \t%s  \nLN:  \t%s  \nBN:  \t%s  \n",
                    customer_rec.cid + 999, customer_rec.fname, customer_rec.mname, customer_rec.lname, customer_rec.bname);
                printf("Addr:  \t%s %s %s %s  \nPhone:  %s\n",
                    customer_rec.street, customer_rec.town,
                    customer_rec.province, customer_rec.postal, customer_rec.phone);
                INVALID_ID = false;
            }
        }

        fclose(sfd);
        break;

    case 2:
        while (INVALID_ID) {

            if (input_id != 0) {//printing only
                id = input_id;
                returnval = return_supplier(sfd, &supplier_rec, id);//1000 base
                if (returnval != -1) {
                    INVALID_ID = false;
                }
            }
            else {//look up and print

                printf("Please enter the Supplier ID starting 1000\n");
                scanf("%d", &id);
                if (id < 1000) {
                    printf("Invalid entry, please enter the number again:\n");
                    if (input_check(input_str) == -1) {
                        break;
                    }
                    scanf("%d", &id);
                }
                returnval = return_supplier(sfd, &supplier_rec, id);//1000 base

                if (supplier_rec.sid < 0) {//invalid id re entry
                    printf("Invalid entry, please enter the number again:\n");

                    //scanf("%d", &id);
                }

            }

            if (id >= 1000 && returnval != -1) {
                printf("\nSID:  \t\t%d  \nManufacturer:  \t%s  \nContact:  \t%s  \nCompany:  \t%s\n",
                    supplier_rec.sid + 999, supplier_rec.manufacturer, supplier_rec.contact, supplier_rec.company);
                printf("Addr:  \t\t%s  \nPhone:  \t%s\nEmail:  \t%s\n",
                    supplier_rec.address, supplier_rec.phone, supplier_rec.email);
                INVALID_ID = false;
            }
        }//end of while

        fclose(sfd);
        break;

    case 3:
        while (INVALID_ID) {
            if (input_id != 0) {//print only
                id = input_id;
                returnval = return_product(sfd, &product_rec, id);//1 base
                if (returnval != -1) {
                    INVALID_ID = false;
                }
            }
            else {//prompt and print
                printf("Please enter the Product ID starting 1\n");
                scanf("%d", &id);

                if (id < 1) {
                    printf("Invalid entry, please enter the number again:\n");
                    if (input_check(input_str) == -1) {
                        break;
                    }
                    scanf("%d", &id);
                }
                returnval = return_product(sfd, &product_rec, id);//1 base

                if (product_rec.pid < 0) {//invalid id re entry
                    printf("Invalid entry, please enter the number again:\n");
                }
            }

            if (id >= 1 && returnval != -1) {
                printf("\nPID: \t\t\t%d \nName: \t\t\t%s \nClassification: \t%s \nManufacturer: \t\t%s \n",
                    product_rec.pid, product_rec.name, product_rec.classification, product_rec.manufacturer);
                printf("Unit Cost: \t\t%s \nManufacturer code: \t%s \nStock: \t\t\t%d \n",
                    product_rec.unit_cost, product_rec.mcode, product_rec.stock_converted);
                INVALID_ID = false;
            }
        }

        fclose(sfd);
        break;
    case 4:
        printf("Please enter the Sale ID starting 1\n");
        scanf("%d", &id);
        fseek(sfd, (id) * sizeof(SALEREC), SEEK_SET);
        fread(&sale_rec, sizeof(SALE), 1, sfd);
        if (sale_rec.saleid < 0) {
            printf("Invalid entry, please enter the number again:\n");
            scanf("%d", &id);
            fseek(sfd, (id) * sizeof(SALEREC), SEEK_SET);
            fread(&sale_rec, sizeof(SALE), 1, sfd);
        }
        if (id > 0) {
            print_sale(sale_rec, sale_rec.tnum_purchased);
            
            printf("Total cost: $%d.%02d\n", sale_rec.tcost / 100, sale_rec.tcost % 100);
        }

            fclose(sfd);
            break;
    case 5://arbitrary value to represent looking for product cost coverted
        fseek(sfd, (id) * sizeof(PREC), SEEK_SET);
        fread(&product_rec, sizeof(PRODUCT), 1, sfd);
        
        temp = product_rec.cost_converted;
        *return_cost = temp;
          
        //fclose(sfd);
        break;

    }
    return;
}

void find_payment(FILE* sfd, int input_id) {
    /*this function finds a specific payment record*/
    PAYMENT pay_rec;

    int id = 0;
    //int n;
    char input_str[MAX];
    id = input_id;
    bool INVALID_ID = true;
    /*look up id*/
    while (INVALID_ID) {
        if (input_id != 0) {//print only
            id = input_id;
            fseek(sfd, (id) * sizeof(PAYREC), SEEK_SET);
            fread(&pay_rec, sizeof(PAYREC), 1, sfd);
            INVALID_ID = false;
        }
        else {//prompt and print
            printf("Please enter the payment ID starting 1\n");
            scanf("%d", &id);

            if (id < 1000) {
                printf("Invalid entry, please enter the number again:\n");
                if (input_check(input_str) == -1) {
                    break;
                }
                scanf("%d", &id);
            }
            fseek(sfd, (id) * sizeof(PAYREC), SEEK_SET);
            fread(&pay_rec, sizeof(PAYMENT), 1, sfd);

            if (pay_rec.payid < 0) {//invalid id re entry
                printf("Invalid entry, please enter the number again:\n");
            }
            else if (pay_rec.pay_status == PAID) {
                printf("Record was paid\n");
                INVALID_ID = false;//still need to print payment
            }
        }
    }//END WHILE

    int d = 0, m = 0, y = 0;
    days2date(pay_rec.due_day, &d, &m, 2021);
    if (id >= 1 && pay_rec.pay_status != PAID) {
        printf("\: \t\t\t%d \: \t\t\t%s \: \t%d/%d/%d \: \t\t%d \n",
            pay_rec.payid, pay_rec.name, d, m, y, pay_rec.amount_owe);
        printf(": \t\t%d\n", pay_rec.cid);

    }
}

//replace line inside find functions
void manufacturer_search(FILE* sfd, char* manufacturer, SUPPLIER* a) //need pass in customer struct
{
    /* Read the file sequentially */
    CUSTOMER customer_rec; //1
    SUPPLIER supplier_rec; //2
    PRODUCT product_rec;   //3
    SALE sale_rec;         //4
    int comp = 0;
    int id = 0;
    int n;
    char contact[MAXLEN];
    char phone[MAXLEN];
    char email[MAXLEN];

    //start from beginning
    n = fseek(sfd, 0, SEEK_SET);

    /* when a zero returns terminate read */
    
    while ((n = fread(&supplier_rec, sizeof(SUPPLIER), 1, sfd)))
        {
            if (supplier_rec.sid > 0) {
                comp = strcmp(supplier_rec.manufacturer, manufacturer);

                if (comp == 0) {
                    strcpy(a->contact, supplier_rec.contact);
                    strcpy(a->phone, supplier_rec.phone);
                    strcpy(a->email, supplier_rec.email);
                    break;
                }
            }
        }
    
    return;
}

/*find_order()*/


