//Note: a zip file is provided with this submission on Bright Space for easy testing
/*code start*/
/*
Name of the program: Relative file for task 6p2
Program summary: This program store customers, suppliers, products and sales of record into relative files
ECED 3401
Oct 30, 2021
Author: Henry Zou & Luigi Cortez
Note: a zip file is provided with this submission on Bright Space
*/

#include "relative.h"

#define MAINON
int current_days = 0;//encoded date

#ifdef MAINON
/*****************main start***********************/
int main(void)
{
    /*all union for all types of file*/
    //SALEREC salefile;
    /*PREC productfile;
    CFREC customerfile;*/
    
    bool START = true;// this is used in while loop for prompts
    //char ch = 0;
    int input = 0;
    int t = 0;           // type
    FILE* infile = NULL;
    CUSTOMER c_struct;   // temporary customer struct
    PRODUCT p_struct;    // temporary product struct
    SUPPLIER s_struct;   // temporary supplier struct 
    SALE sale_struct;    // temporary sale struct
    //BACKORDER backorder_struct; // temporary backorder struct
    HEADER header;//temporary header
    int menu_choice = -1;
    int num = 0;
    int return_cost = 0;
    int* rc_ptr = &return_cost;
    char input_string[MAX];

    // User interface and input
    while (START) {
        /*prompt days for comparison*/
        
        //printf("\nCurrent date:\n");
        //int d = 0, m = 0, y = 0;
        //date_read(&d,&m,&y);
        //current_days = date2days(d,m,y);//will give current encoded date
        
        //current_day_prompt();
        //process_backorder();
        //sequential_find_pay( sfd,  current_days) ;//paydue reminder
        //current_days = 300;
        printf("\nPlease enter the kind of operations you want to do: \n");
        printf("Main Menu:\n0 - Exit Program\n1 - Make a sale\n2 - Add single customer, supplier or product\n3 - Look up\n"
            "4 - Update a customer, supplier or product\n5 - Delete a customer, supplier or product\n");
        menu_choice = get_input(input_string, '5');
        switch (menu_choice) {
            case 0:
                START = false;
                break;

            case 1: // Make a Sale
                num = 4;//sale is 4
                create_bf(&sfd, num); //define_bf, defined sales file
                make_a_sale(sfd, &salefile.hrec, &productfile.hrec, &customerfile.hrec, &backorderfile.hrec, &backorder_struct, current_days);
                fclose(sfd);
                break;
            case 2:
                printf("\nPlease enter the data type you want to add:\n0 - To the main menu\n1 - Add a customer\n2 - Add a supplier\n3 - Add a product \n");

                add_menu();
                    break;
            case 3: // Look up
                //printf("\nLook Up Menu:\n0 - Previous menu\n1 - Look up customers\n2 - Look up suppliers\n3 - Look up products\n4 - Look up sale \n");
                lookup_menu();
                break;
            case 4:
                //printf("\nPlease enter the data type you want to update:\n"
                //    "0 - Return to main\n1 - Update Customers\n2 - Update Suppliers\n3 - Update Products\n");
                update_menu();
                break;
            case 5:
                /*printf("\nPlease enter the data type you want to delete:\n"
                    "0 - Return to main\n1 - Delete Customers\n2 - Delete Suppliers\n3 - Delete Products\n");*/
                delete_menu();
                break;
        }
    }
    return 0;
}
#endif