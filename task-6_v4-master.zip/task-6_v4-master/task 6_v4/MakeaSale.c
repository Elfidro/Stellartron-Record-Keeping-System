/*
Program summary: contains make a sale functions
ECED 3401
Oct 17, 2021
Author: Henry Zou & Luigi Cortez
*/

#include "relative.h"

void print_sale(SALE a, int i) {
    char space = 32;
    printf("\nSale ID \t|\tCustomer ID\t|\tCustomer Name\t\t|\tTotal Number of items purchased\n");//can be combined in look up
    printf(" %d%16c  %8d%3c \t\t%16s%4c \t\t\t %d%8c  \n\n",
        a.saleid, space, a.cid, space, a.cname, space, a.tnum_purchased, space);
    printf("Items purchased: \n");
    printf("Item ID \t|\t\tName of the Product\t\t|\t# of the Product\t|\tUnitcost\n");
    int k = 0;
    for (k = 0; k < i; k++) {
        int temp = a.num_purchased_arr[k];

        printf(" %d%20c ", a.pid_arr[k], space);
        printf(" %30s%10c ", a.product_names[k], space);
        printf(" x%7d%8c ", a.num_purchased_arr[k], space);
        printf(" %20c$%d.%02d \n\n", space, a.product_unit_cost_arr[k] / 100, a.product_unit_cost_arr[k] % 100);
        k = k + temp-1;
    }
}

void make_a_sale(FILE* sfd, HEADER* header_ptr, HEADER* cheader_ptr, HEADER* pheader_ptr, HEADER* bheader_ptr, BACKORDER* a, int current_days)
{
    /*this function make a sale and store the sale data in file*/
    SALEREC newsale;
    BACKREC backorderfile;
    FILE* p_ptr;
    FILE* c_ptr;
    FILE* b_ptr;
    int id=0;
    int return_cost = 0;//total cost in cents
    int* rc_ptr = &return_cost;//store address of the total cost
    int num = 0;//number of items purchased
    int ids;
    int returnval = 0;
    bool CHECK_VALID_ID = true;
    PRODUCT product_rec;
    CUSTOMER customer_rec;
                    
    /*Read a sale*/
    //customers id entry
    create_bf(&c_ptr, 1);
    fseek(sfd, 0, SEEK_SET);
    fread(cheader_ptr, sizeof(CFREC), 1, c_ptr);
    while (CHECK_VALID_ID) {
        printf("Please enter customer id (starts from 1000) for the purchase:\n");
        scanf("%d", &ids);
        char input_arr[MAX];
        returnval = return_customer(c_ptr, &customer_rec, ids);//1000 base

        int temp = 0;
        temp = ids - 999;
        if (temp > cheader_ptr->first_id-1 || temp <= 0) {
            printf("Invalid customer id\n");    
            if (input_check(input_arr) == -1) {
                break;
            }
        }
        else if(returnval!=-1){
            CHECK_VALID_ID = false;
            //stores
            newsale.salerec.cid = ids;
            strcpy(newsale.salerec.cname, customer_rec.cname);

            // backorder stores
            a->cid = ids;
            strcpy(a->phone, customer_rec.phone);
            strcpy(a->cname, customer_rec.cname);
        }
    }
    fclose(c_ptr);

    //product id entry
    int i = 0;
    int n = 0;
    int j = 0;
    CHECK_VALID_ID = true;
    create_bf(&p_ptr, 3);
    fread(pheader_ptr, sizeof(PREC), 1, p_ptr);
    //backorder variables
    bool CHECK_INPUT = true;
    char strin[MAX];
    SREC supplierfile;
    ORDERREC orderfile;
    
    while (CHECK_VALID_ID) {
        char input_arr[MAX];
        printf("Please enter product id, 0 to exit. \n");
        scanf("%d", &ids);
        
        if (ids > pheader_ptr->first_id-1 || ids < 0 ) {
            printf("Invalid product id\n");
            if (input_check(input_arr) == -1) {//this debugs the scanf
                CHECK_VALID_ID = false;
            }
        }
        else if (ids == 0) {
            CHECK_VALID_ID = false;
        }
        else 
        {
            bool INVALID_NUM = true;
            int num = -1;

            while (INVALID_NUM) {
                printf("Please enter #of this products purchased, 0 to exit. \n");
                scanf("%d", &num);

                if (num < 0) {
                    printf("Invalid num\n");
                    if (input_check(input_arr) == -1) {
                        break;
                    }
                }
                else if (num == 0) {
                    printf("\n");
                    INVALID_NUM = false;
                }

                if (num > 0) {
                    returnval = return_product(p_ptr, &product_rec, ids);//1 base
                    int temp_stock = 0, stock = 0, order_amount;
                    char name = product_rec.name;
                    int reorder = 0;
                    stock = product_rec.stock_converted;
                    temp_stock = product_rec.stock_converted;
                    /*check reorder levels*/
                    
                    reorder = product_rec.reorder_level_converted;

                    temp_stock = temp_stock - num; //remove from stock
                    
                    if (reorder > stock || temp_stock == 0) {
                        order_amount = reorder - stock;
                        if (order_amount <= 0) {
                            order_amount = reorder - temp_stock;
                        }
                        printf("\nSince stock is below reorder level, an order is created.\n");
                        fclose(p_ptr);
                        create_bf(&sfd, 7);
                        place_order(sfd, &orderfile.hrec, &supplierfile.hrec, &productfile.hrec, ids, 100, order_amount);
                        fclose(sfd);
                        create_bf(&p_ptr, 3);
                        fread(pheader_ptr, sizeof(PREC), 1, p_ptr);
                    }
                    if (temp_stock < 0) {
                        printf("Not enough stock. The number of stock left is %d\n", product_rec.stock_converted);
                        /*backorder*/
                        while (CHECK_INPUT) {
                            printf("\nWould you like to create a backorder? (yes/no)\n");
                            CHECK_INPUT = create_backorder(a, product_rec, num, ids, current_days);
                            INVALID_NUM = false;
                        }
                        CHECK_INPUT = true;
                    }
                    else {
                        for (int k = 0; k < num; k++) {//same item purchase
                            newsale.salerec.num_purchased_arr[i] = num;
                            newsale.salerec.pid_arr[i] = ids;
                            strcpy(newsale.salerec.product_names[i], product_rec.name);
                            newsale.salerec.product_unit_cost_arr[i] = product_rec.cost_converted;
                            i++;
                        }
                        /*update stock*/
                        product_rec.stock_converted = product_rec.stock_converted - num;//remove from stock
                        fseek(p_ptr, ids * sizeof(PREC), SEEK_SET);
                        fwrite(&product_rec, sizeof(PREC), 1, p_ptr);//Write product data to customer file
                        INVALID_NUM = false;
                    }
                    
                }
            }
        }
    }
    fclose(p_ptr);

    //this function goes through the data recording for a new sale
    
    fseek(sfd, 0, SEEK_SET);
    fread(header_ptr, sizeof(SALEREC), 1, sfd);

    if (header_ptr->first_id < 0.5) {

        //printf("Start of initialization\n");

        header_ptr->del_rec_list = INVALIDLONG;	/* Deleted list is empty */
        header_ptr->first_id = 1;	    	/* First record is 1*/

        /* Default opening record is 0 (Header) */
        fseek(sfd, 0, SEEK_SET);

        fwrite(header_ptr, sizeof(HEADER), 1, sfd);

        //printf("End of intialization\n");
    }
    /* Access header record to get first available customer id */
    id = header_ptr->first_id;

    /* Move to customer record */
    /*if (fseek(sfd, id * sizeof(SALEREC), SEEK_SET) < 0)
    {
        printf("Invalid id\n");
        getchar();
        return;
    }*/
    newsale.salerec.tnum_purchased = i;
    
    /* Complete remaining fields */
    newsale.salerec.saleid = id;

    print_sale(newsale.salerec, i);

    //return the total cost in int
    
    int temp = 0;
    FILE* tempf;
    create_bf(&tempf, 3);
    for (j = 0; j < i; j++) {
        int t = 5;
        find(t, tempf, rc_ptr, newsale.salerec.pid_arr[j]);//return cost

        temp = temp + return_cost;//this is PID array

    }
    newsale.salerec.tcost = temp;
    printf("Total cost: ");
    printf("$%d.%02d\n", temp / 100, temp % 100);
    fclose(tempf);

    //- Write sale data to sale file
    fwrite(&newsale, sizeof(SALEREC), 1, sfd);

    fseek(sfd, 0, SEEK_SET);//go back to header
    header_ptr->first_id = header_ptr->first_id + 1;
    fwrite(header_ptr, sizeof(SALEREC), 1, sfd);

    fclose(sfd);
    return;
}
